﻿var TableSorter = {
    order: "", //'ascending' or 'descending'
    sort: function (table, index, order, customSortMethod) {
        TableSorter.order = order;
        var selector = "td:nth-child(_ID_)"; //--->(2)
        selector = selector.replace("_ID_", parseInt(index) + 1); //--->(2)
        //var thisColumn = $(table).find(selector); //--->(1)

        var thisColumn = $(table).find("tr:gt(0)").children(selector); //--->(2)
        var objList = [];
        var txt = "";
        $.each(thisColumn, function (index, val) {
            txt += "," + $(val).text();
            var sb = {};
            sb.name = $(val).text();
            sb.row = $(val).parent();
            objList.push(sb);
        });
        TableSorter.sortTable(objList, table, customSortMethod);
    },
    sortTable: function (curList, table, customSortMethod) {
        if (customSortMethod != undefined) curList.sort(customSortMethod);
        else curList.sort(TableSorter.SortByName);
        $.each(curList, function (i, v) {
            $(table).append($(v.row));
        });
    },
    SortByName: function (a, b) {
        var aName = a.name;
        var bName = b.name;
        if ($.isNumeric(aName)) {
            aName = parseInt(aName);
            bName = parseInt(bName);
            if (aName == bName) return 0;
            if (aName < bName) {
                if (TableSorter.order == 'ascending') return -1
                return 1;
            }
            if (TableSorter.order == 'ascending') return 1;
            return -1;
        }
        var retVal = aName.localeCompare(bName);
        if (TableSorter.order == 'ascending') retVal *= -1;
        return retVal;
    }
};

function TableWidget(jData, headerMapper, ColumnsToShowHide) {
    this.jData = jData;
    this.headerMapper = headerMapper;
    this.ColumnsToShowHide = ColumnsToShowHide;
    this.theJContainer = {};
    this.Modify;
    this.Remove;
    this.RowCallBack;
    this.ItemClickCallBack;
    this.Starter = "<table>";
    this.Ender = "</table>";
    this.htmlTr = "<tr mydata = '_MDATA_' showData = '_SHOW_OFF_' >";
    this.htmlTrEndersGame = "</tr>";
    this.htmlTd = "<td zAttr='_KEY_'>_VAL_</td>";
    this.htmlModify = "<td><input id='temp' events style='display:_DISPLAY_'  type='button' zAttr='Modify' class='rowBut' value='Mod'><input events zAttr='Remove_Row' id='temp' style='display:_DISPLAY_' class='rowBut' type='button' value='X'></td></tr>";
    this.Operations = "<th style='font-size:30px;'>&pi;/&psi;</th></tr>";
    this.Sorting = "<div tpe='ascending' style='cursor:pointer;float:right;'>&uArr;</div><div tpe='descending' style='cursor:pointer;float:right;clear:right;'>&dArr;</div>";
    this.Table = {};
    this.isTable = true;
}
TableWidget.prototype.isColumnToBeRendered = function (k) {
    var that = this;
    if (undefined == that.ColumnsToShowHide) return true;
    if (!that.ColumnsToShowHide.hasOwnProperty(k)) return false;
    if (that.ColumnsToShowHide[k] == false) return false;
    return true;
}
TableWidget.prototype.makeTable = function (theArray) {
    if (theArray != undefined) this.jData = theArray;
    var mydata = this.jData;
    if (undefined == mydata || mydata.length <= 0) return;
    var headerMapper = this.headerMapper;
    var that = this;

    var table = $(this.Starter + this.Ender);
    that.Table = table;
    var htmlTd = that.htmlTd;
    var htmlModify = that.htmlModify;

    var tblHeader = "<tr>";
    if (that.isTable) {
        for (var k in mydata[0]) {
            if (k == 'modType') continue;
            var head = k;
            if (!that.isColumnToBeRendered(k)) continue;
            if (undefined != headerMapper) {
                if (headerMapper.hasOwnProperty(k)) head = headerMapper[k];
                else head = k;
            }
            tblHeader += "<th>" + head + this.Sorting + "</th>";
        }
        if (this.Modify != undefined) tblHeader += that.Operations;
        $(tblHeader).appendTo(table).click(function (e) {
            // if ($(e.target).attr("modType") == undefined) return;
            TableSorter.sort($(e.target).closest("table"), parseInt($(e.target).parent().index()), $(e.target).attr("tpe"), undefined);
        });
    }
    $.each(mydata, function (index, value) { //each row/object
        var theRow = that.AddRowInternal(value, false);
    });
    return that.Table;
};
TableWidget.prototype.RowModificationsClick = function (e) {
    var whichButton = $(e.target).attr("zAttr");
    var that = e.data.that;
    switch (whichButton) {
        case "Modify":
            var theJContainer = $(e.target).closest("tr");
            //theJContainer.attr("NowOpen", "1");
            that.theJContainer = theJContainer;
            $(that.theJContainer).css({
                "background-color": 'yellow'
            });
            if (that.Modify == undefined) break;
            var rowData = JSON.parse(theJContainer.attr('mydata'));
            //delete rowData.modType;
            that.Modify(rowData);
            break;
        case "Remove_Row":
            alert("Remove Row\nfrom TableWidget.prototype.RowModificationsClick");
            var theJContainer = $(e.target).closest("tr");
            that.theJContainer = theJContainer;
            if (undefined == that.Remove) return;
            var rowData = JSON.parse(theJContainer.attr('mydata'));
            delete rowData.modType;
            that.Remove(rowData);
            break;
    }
};
TableWidget.prototype.AddRow = function (jData) {
    var tr = this.AddRowInternal(jData, true);
    $(tr).animate({
        backgroundColor: 'yellow'
    }, 1500, function () {
        $(tr).animate({
            backgroundColor: 'transparent'
        }, 1000, function () {
            $(tr).css({
                "background-color": 'transparent'
            });
        });
    });
    return tr;
};
TableWidget.prototype.AddRowInternal = function (jData, isRowNew) {
    var that = this;
    var TableRow = that.htmlTr;
    var htmlModify = that.htmlModify;
    var theTable = that.Table;
    if (isRowNew) jData.modType = 'N';//'N' = New Row,'U' = Unmodified Row, 'M' = Modified Row
    else jData.modType = 'U'
    TableRow = TableRow.replace('_MDATA_', JSON.stringify(jData));
    var ModifiedObject = {
        toAddButtons: false,
        FinalData: jData
    };
    if (that.RowCallBack != undefined) ModifiedObject = that.RowCallBack(JSON.parse(JSON.stringify(jData)));
    TableRow = TableRow.replace('_SHOW_OFF_', JSON.stringify(ModifiedObject));
    $.each(ModifiedObject.FinalData, function (key, val) { //for each key in object
        if (key == 'modType') return;
        if (!that.isColumnToBeRendered(key)) return;
        var td = that.htmlTd;
        td = td.replace('_KEY_', key).replace('_VAL_', val);
        TableRow += td;
    });
    if (this.Modify != undefined) {
        if (ModifiedObject == undefined || ModifiedObject.toAddButtons) TableRow += htmlModify;
        else TableRow += "<td></td>";
    }
    TableRow += that.htmlTrEndersGame;
    var tr = $(TableRow);
    tr.appendTo(theTable).find("input[type='button'][events]").bind("click", {
        that: that
    }, that.RowModificationsClick);
    tr.bind("click", {
        that: that
    }, that.RowClick);
    //$(tr).attr('mydata', JSON.stringify(jData));
    //$(tr).attr('showData', JSON.stringify(ModifiedObject));
    return tr;
};
TableWidget.prototype.RowClick = function (e) {
    var that = e.data.that;
    if (that.ItemClickCallBack == undefined) return;
    that.ItemClickCallBack(e, JSON.parse($(e.target).closest("[mydata]").attr("mydata")));
};
TableWidget.prototype.RemoveRow = function (theData) {
    if (theData == undefined || theData == null) return;
    var that = this;
    that.theJContainer.remove();
};
TableWidget.prototype.UpdateRow = function (theData) {
    //$(this.theJContainer).css({ "background-color": 'transparent' });
    var that = this;
    $(that.theJContainer).animate({
        backgroundColor: 'transparent'
    }, 1500, function () {
        $(that.theJContainer).css({
            "background-color": 'transparent'
        });
    });

    if (theData == undefined || theData == null) return;

    var source = JSON.parse(that.theJContainer.attr("mydata"));
    var toContinue = false;
    for (var k in theData) {
        try {
            if (theData[k] != source[k]) toContinue = true;
        } catch (err) {
            return;
        }
    }
    if (!toContinue) return;
    var ModifiedObject = {
        toAddButtons: false,
        FinalData: theData
    };
    if (that.RowCallBack != undefined) {
        //{toAddButtons:true,FinalData:{}}
        ModifiedObject = that.RowCallBack(JSON.parse(JSON.stringify(theData)));
        that.theJContainer.attr('showData', JSON.stringify(ModifiedObject));
    }
    for (var k in ModifiedObject.FinalData) {
        var theEle = that.theJContainer.find("td[zAttr='" + k + "']");
        if (theEle.length <= 0) continue;

        theEle.text(ModifiedObject.FinalData[k]);
        source[k] = theData[k];
    }
    if (source.modType == 'U') source.modType = 'M';
    that.theJContainer.attr("mydata", JSON.stringify(theData));
    that.theJContainer = undefined;
};
TableWidget.prototype.GetModifiedObjects = function (all, allButThisRow) {
    if (all == undefined) return;
    var that = this;
    var rowDatas = that.Table.find("tr[myData]");
    var dataCollectector = [];
    $.each(rowDatas, function (key, val) {
        if (allButThisRow != undefined) {
            var simha = that.theJContainer;
            var ahimsa = $(val);
            if (simha.is(ahimsa)) return;
        }
        var rowObject = JSON.parse($(val).attr("myData"));
        if (all) dataCollectector.push(rowObject);
        else if (rowObject.modType == 'N' || rowObject.modType == 'M') dataCollectector.push(rowObject);

    });
    return dataCollectector;
};