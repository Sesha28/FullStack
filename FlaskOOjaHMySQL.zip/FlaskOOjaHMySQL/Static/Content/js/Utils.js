﻿jQuery.browser = {};
(function () {
    jQuery.browser.msie = false;
    jQuery.browser.version = 0;
    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
        jQuery.browser.msie = true;
        jQuery.browser.version = RegExp.$1;
    }
})();
Array.prototype.removeIf = function (callback) {
    var i = this.length;
    while (i--) {
        if (callback(this[i], i)) {
            this.splice(i, 1);
        }
    }
};
var utils = {
    getMonthIndex: function () {
        var d = new Date();
        var n = d.getMonth() + 1;//JS month starts with 0 , and C# month starts with 1
        return n;
    }
}
var domUtils = {
    cleanTableAfterFirstTH: function (tableid) {
        var index = $("#" + tableid + " tr th").parent().index();
        $("#" + tableid + " tr:gt(" + index + ")").remove();
    }
}
$.MyAlertBox = function (msg ,title) {
    $('<div></div>').appendTo('body')
                    .html('<div><h6>'+msg+'</h6></div>')
                    .dialog({
                        //modal: true,
                        title: (title == undefined) ? 'Alert!!' : title,
                        autoOpen: true,
                        width: 'auto',
                        resizable: false,
                        buttons: {
                            OK: function () {                                
                                $(this).dialog("close");
                                //CallBack(0);
                            }
                        },
                        close: function (event, ui) {
                            $(this).remove();
                        }
                    });
}
$.MyConfirmBox = function (msg, title, CallBack) {
    $('<div></div>').appendTo('body')
                    .html('<div><h6>' + msg + '</h6></div>')
                    .dialog({
                        //modal: true,
                        title: (title == undefined) ? 'Delete message' : title,
                        autoOpen: true,
                        width: 'auto',
                        resizable: false,
                        buttons: {
                            Yes: function () {
                                // $(obj).removeAttr('onclick');                                
                                // $(obj).parents('.Parent').remove();
                                $(this).dialog("close");
                                CallBack(1);
                            },
                            No: function () {
                                $(this).dialog("close");
                                CallBack(0);

                            }
                        },
                        close: function (event, ui) {
                            $(this).remove();
                        }
                    });
}
function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
function ReplaceDangerousChars() { return this.replace(/&nl/g, '<br/>').replace(/&as/g, "'") }
String.prototype.ReplaceDanger = ReplaceDangerousChars;

function RandomString(len) { return Array.from({ length: len }, i => String.fromCharCode(Math.round(Math.ceil(Math.random() * 25) + 65))).join(''); }
Math.RandomString = RandomString;

$.makeTable = function (mydata, cssClass, HeaderMapping, callback) {
    if (!cssClass) cssClass = "display table table-bordered table-secondary table-hover table-stripped table-light";
    var table = $('<table border="1" id="example" class="' + cssClass + '">');
    var tblHeader = '<thead ><tr>';
    for (var k in mydata[0]) {
        if (HeaderMapping) tblHeader += "<th>" + HeaderMapping[k] + "</th>";
        else tblHeader += "<th>" + k + "</th>";
    }
    tblHeader += "</tr></thead>";
    $(tblHeader).appendTo(table);
    var TableRow = "<tbody>";
    $.each(mydata, function (index, value) {
        TableRow += "<tr id=_ID_>".replace("_ID_", value.name);
        $.each(value, function (key, val) {
            if (callback) TableRow += "<td>" + callback(key, val, value) + "</td>";
            else TableRow += "<td>" + val + "</td>";
        });
        TableRow += "</tr>";
    });
    TableRow += "</tbody>";
    var tblFooter = "<tfoot><tr>";
    for (var k in mydata[0]) tblFooter += "<th>" + k + "</th>";
    tblFooter += "</tr></tfoot>";
    TableRow += tblFooter;
    $(table).append(TableRow);
    return ($(table));
};
$.NavigateTo = function NavigateTo(id) {
    //window.location.href = id;
    setTimeout(() => {
        let jEleContainer = $("#" + id);
        $('html, body').animate({
            scrollTop: jEleContainer.offset().top
        }, 500);
    }, 500);
}
String.prototype.separateWord = function () { return this.replace(/([A-Z])/g, ' $1').trim() };
