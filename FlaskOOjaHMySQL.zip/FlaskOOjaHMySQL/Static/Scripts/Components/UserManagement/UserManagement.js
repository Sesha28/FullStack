﻿var UserManagement = {
    current_user_details: null,
    status: null, //new, edit
    myModal: null,
    DataTableInstance: null,
    action_cell: `<div class="row">
                   <div class="col-6">
                      <button class='btn btn-sm btn-danger' onclick="UserManagement.delete_row(event)"><i class='bi bi-trash'></i></button>
                   </div>
                   <div class="col-6">
                      <button class='btn btn-sm btn-primary' onclick="UserManagement.edit_row(event)"><i class="bi bi-pen"></i></button>
                   </div>
                </div>`,
    pwd_field: `
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-key"></i></span>
            <input readonly value="_VALUE_" type="password" id="pwd__ID_" class="form-control" name="pwd" placeholder="Password" aria-label="Password" aria-describedby="basic-addon1">
            <span class="input-group-text" onmousedown="$('#pwd__ID_').attr({'type': 'text'})" onmouseup="$('#pwd__ID_').attr({'type': 'password'})">
                <i class="bi bi-eye pe-none"></i>
            </span>
        </div>
    `,
    start_action: function (tag, data) {
        return new TemplateRenderer(data, tag, "~/Scripts/Components/UserManagement/UserManagement.html", null, false).start_action().
            then(vals => {
                UserManagement.DoUserTable();
                return vals + "user management successfully placed";
            });
    },
    search: function (e, index) {
        let txt = e.target.value; //if (!txt) return;
        if (e.keyCode != 13) return;
        UserManagement.DataTableInstance.column(index).search(txt).draw();
    },
    doclick_expt: function (e) {
        UserManagement.DataTableInstance.column(1).search('').draw();
    },
    DoUserTable: function () {
        UserManagement.DataTableInstance = $('#users_table').DataTable({
            aLengthMenu: [[10, 15, 20, -1], [10, 15, 20, "All"]], //combobox - display and value 
            pageLength: 10,
            processing: true,
            serverSide: true,
            //search: true,
            //searching: false,
            destroy: true,
            ajax: {
                "url": config.contextPath + "Home/GetUsers",
                "type": "GET"
            },
            columns: [
                { data: "id" },
                { data: "name" },
                { data: "mail" },
                { data: "pwd" },
                { data: "is_default" },
                { data: "roles" },
                { data: "the_time" },
                {
                    data: null,
                    render: function (data, type, row) {
                        return UserManagement.action_cell.replace(/_ROW_/g, JSON.stringify(row));
                    }
                }
            ],
            columnDefs: [
                {
                    //Creation date
                    render: (data, type, row) => `<span class='fs-tiny' 
                    onmouseover='$(this).removeClass("fs-tiny").addClass("fs-6");' onmouseout='$(this).removeClass("fs-6").addClass("fs-tiny");'>` + moment(data).format('llll') + `</span>`,
                    targets: 6
                },
                {
                    //Creation date
                    render: (data, type, row) => UserManagement.pwd_field.replace(/_VALUE_/g, data).replace(/_ID_/g, row.id),
                    targets: 3
                },
                {
                    "orderable": false,
                    "targets": 7,
                },
            ],
            initComplete: function () {
                $("#users_table_filter").hide();
                $("#users_table_length").addClass("badge border border-1 p-2 mb-2 rounded-2");
                $("#users_table_info").addClass("badge border border-1 p-3 mt-4 rounded-2");
                $("#users_table_paginate").addClass("badge border border-1 p-3 mt-4 rounded-2");
            },
        });
    },
    delete_row: function (e) {
        let tr = $(e.target).closest("tr");

        //get row data from datatable
        let data = UserManagement.DataTableInstance.row(tr).data();
        Alertify.ShowAlertDialog({
            "title": "Be sure what you want to do",
            "body": "Are you sure you want to delete <b>" + data.name + "</b>",
            "buttons": ["No NO NO dont Delete, i was just playing ", "Yes Delete"],
            "foot_note": "Welcome to DFQ<sub class='fs-tiny'>REQ</sub>"
        }, async (action) => {
            //first button click action =false, second button click action=true
            if (action) {
                alert("OMG now I will send delete request")
            }
        });
    },
    edit_row: function (e) {
        UserManagement.status = "edit";
        let element = document.getElementById('user_data');
        let options = {}; options.focus = true; options.keyboard = true;
        if (UserManagement.myModal === null) UserManagement.myModal = new bootstrap.Modal(element, options);
        UserManagement.myModal.show(3000);
        let tr = $(e.target).closest("tr");
        //get row data from datatable
        UserManagement.current_user_details = UserManagement.DataTableInstance.row(tr).data();
        $("#user_name").val(UserManagement.current_user_details.name);
        $("#user_mail").val(UserManagement.current_user_details.mail);
        $("#user_pwd").val(UserManagement.current_user_details.pwd);
        $("#user_roles").find("option").removeAttr("selected");
        switch (UserManagement.current_user_details.roles.toLowerCase()) {
            case "admin":
                $("#user_roles").find("option[value='1']").attr("selected", "selected");
                break;
            case "user":
                $("#user_roles").find("option[value='0']").attr("selected", "selected");
                break;
            case "manager":
                $("#user_roles").find("option[value='2']").attr("selected", "selected");
                break;
        }
        $("#is_default_yes").hide(); $("#is_default_no").hide();
        UserManagement.current_user_details.is_default === 1 ? $("#is_default_yes").show() : $("#is_default_no").show();
    },
    add_new: function (e) {
        UserManagement.status = "new";
        let element = document.getElementById('user_data');
        let options = {}; options.focus = true; options.keyboard = true;
        if (UserManagement.myModal === null) UserManagement.myModal = new bootstrap.Modal(element, options);

        UserManagement.myModal.show(3000);
        //$("#user_name").val("");
        //$("#user_mail").val("");
        //$("#user_pwd").val("");
        //$("#user_roles").find("option[value='0']").attr("selected", "selected");
    },
    SaveUserDetails: function (e) {
        let name = $("#user_name").val().trim();
        let mail = $("#user_mail").val().trim();
        let pwd = $("#user_pwd").val().trim();
        let role = $("#user_roles").val().trim();//0-user, 1-admin, 2-manager
        let is_default = parseInt($("input[type='radio'][name='pwd_status']:checked").val());

        if (!name) {
            UserManagement.highlightFormField("#user_name");
            return false;
        }
        if (!mail) {
            UserManagement.highlightFormField("#user_mail");
            return false;
        }
        if (!pwd) {
            UserManagement.highlightFormField("#user_pwd");
            return false;
        }
        switch (UserManagement.status) {
            case "edit": {
                //return if there is no change in the data
                if (UserManagement.current_user_details.name.trim() === name
                    && UserManagement.current_user_details.mail.toLowerCase() === mail.toLowerCase()
                    && UserManagement.current_user_details.pwd.toLowerCase() === pwd.toLowerCase()
                    && UserManagement.current_user_details.is_default === is_default
                    && UserManagement.current_user_details.roles.toLowerCase() === UserManagement.GetRole(parseInt(role.toLowerCase()))) {
                    UserManagement.myModal.hide();
                    //alert("No changes detected");
                    setTimeout(() => {
                        Alertify.ShowAlertDialog({
                            "title": "This is atrocious !!!",
                            "body": "<b>Are you Acting Clever ? I saw there are no changes at all</b>",
                            "buttons": ["Hi hi, i was just playing ", "Sorry, won't do it next time"],
                            "foot_note": "Welcome to DFQ<sub class='fs-tiny'>REQ</sub>"
                        });
                    }, 1000);
                    return;
                }
                else {
                    let sendData = { "user_id": UserManagement.current_user_details.id, "name": name, "mail": mail, "pwd": pwd, "role": role, "is_default": is_default };
                    //alert("Updating User\n" + JSON.stringify(sendData, null, ' '));
                    $.ajax({
                        url: config.contextPath + "Home/UpdateUser",
                        data: sendData
                    }).then(jData => {
                        UserManagement.myModal.hide();
                        if (jData.indexOf("Success") !== -1) UserManagement.DataTableInstance.column(1).search('').draw();
                        alert(jData.separateWord())
                    });
                }
                break;
            }
            case "new": {
                let sendData = { "name": name, "mail": mail, "pwd": pwd, "role": role, "is_default": is_default };
                //alert("Creating User\n" + JSON.stringify(sendData, null, ' '));
                $.ajax({
                    url: config.contextPath + "Home/CreateUser",
                    data: sendData
                }).then(jData => {
                    UserManagement.myModal.hide();
                    if (jData.indexOf("Success") !== -1) UserManagement.DataTableInstance.column(1).search('').draw();
                    alert(jData.separateWord());
                });
                break;
            }
        }
        //alert(UserManagement.status);
    },
    GetRole: function (role_id) {
        switch (role_id) {
            case 0:
                return "user";
            case 1:
                return "admin";
            case 2:
                return "manager";
        }
    },
    highlightFormField(jid) {
        setTimeout(() => {
            $(jid).addClass('glow');
            setTimeout(() => $(jid).removeClass('glow'), 5000);
        }, 500)
    },
}