﻿var Formula = {
    start_action: function (tag, data) {
        return new TemplateRenderer(data, tag, "~/Scripts/Components/Formula/Formula.html", null, false).start_action().
        then (jData => Formula.DisplayValues());
    },
    DisplayValues: function () {
        //$("div[stat]").toggleClass("rotateZOnce", true);
       
    },
  
}