﻿var Constantinople = {
    SGR_L0: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    SGR_L1: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    SGR_L2: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    SGR_L3: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },   
    SGR_L4: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    PGR_L0: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    PGR_L1: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    PGR_L2: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    PGR_L3: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    PGR_L4: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_A_L0: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_A_L1: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_A_L2: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_A_L3: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_A_L4: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_I_L0: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_I_L1: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_I_L2: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_I_L3: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    CGR_I_L4: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FEI_L0: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FEI_L1: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FEI_L2: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FEI_L3: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FEI_L4: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    IQA_L0: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    IQA_L1: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    IQA_L2: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    IQA_L3: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    IQA_L4: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    VGR_L0: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    VGR_L1: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    VGR_L2: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    VGR_L3: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    VGR_L4: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FQA_L0: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FQA_L1: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FQA_L2: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FQA_L3: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    },
    FQA_L4: {
        OldProjectConstants: {
            emptyPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, identifiedPercent: { criticality: -2, target: 0 },
            definedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: 1, target: 0 }, coveredPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For legacy projects your score should be 100% to be considered as a good project"
        },
        NewProjectConstants: {
            identifiedPercent: { criticality: -2, target: 0 }, rejectedPercent: { criticality: -3, target: 100 }, characterizedPercent: { criticality: -2, target: 0 },
            assignedPercent: { criticality: -1, target: 0 }, coownPercent: { criticality: -1, target: 0 }, analyzedPercent: { criticality: 1, target: 100 },
            traced_by_implPercent: { criticality: 2, target: 0 }, covered_by_implPercent: { criticality: 2, target: 0 },
            traced_by_mopPercent: { criticality: 2, target: 0 }, covered_by_mopPercent: { criticality: 2, target: 0 },
            demonstratedPercent: { criticality: 3, target: 0 }, obsoletePercent: { criticality: 1, target: 0 },
            message: "For modern projects your score should be 100% to be considered as a good project"
        },
    }
}