﻿var Autostat = {
    GraphData: null,
    IncludedGraphsForComparativeStudies: ["TotalManualEffort", "EffortAfterCurrentAutomation", "AverageCurrentAutomation", "EffortAfterFutureAutomation", "AverageFutureAutomation"],
    CurrentTypeForComparativeStudies: "bar",
    start_action: function (jDataForHTML, tag) {
        return (new TemplateRenderer(jDataForHTML, tag, "~/Scripts/Components/Autostat/Autostat.html", null, false, true).start_action())
            .then(async (value) => {
                await Autostat.ShowGraphOnLoad(); // Await the execution to ensure graphs are loaded
                // Graphs.MakeDummyGraph("dummy_canvas"); // If needed, keep your dummy graph call here
                Autostat.SetupEventListeners(); // Set up event listeners after the initial action
                return value + " Autostat rendered";
            });
    },

    ShowGraphOnLoad: async function () {
        $("#error_info").hide();
        try {
            const graphData = await Autostat.GetGraphData();
            Autostat.GraphData = graphData;
            Autostat.InitializeGraphs();
        } catch (err) {
            console.error("Error fetching data:", err);
            $("#error_info").show().html("Failed to load data.");
        }
    },
    ShowError: function (jData) {
        $("#error_info").show().html(jData.data).height($("#error_info")[0].scrollHeight);
        $("#all_graphs").hide();
    },
    GetGraphData: function () {
        return $.ajax({
            url: `${prefix}/update_graph`,
            type: 'POST',
            dataType: 'json'
        }).then(response => {
            if (!response) throw "No Data Found in the Data Source";
            return response;
        });
    },

    InitializeGraphs: function () {
        Object.entries(this.GraphData).forEach(([key, html]) => {
            $(`#${key}_chart_div`).html(html);
            $(`#${key}_chart_div`).hide();
        });
        this.ShowChart(this.chartType);
    },

    ShowChart: function (chartType) {
        this.chartType = chartType;
        Object.keys(this.GraphData).forEach(key => {
            $(`#${key}_chart_div`).hide();
        });
        $(`#${chartType}_chart_div`).show();
    },

    SetupEventListeners: function () {
        $('.chart-btn').on('click', function () {
            const chartType = $(this).data('chart-type');
            Autostat.ShowChart(chartType);
        });
    },
    ShowGraphOnLoad: function () {
        $("#error_info").hide();
        Autostat.GetGraphData().then(jData => {
            if (jData.WhatHappened < 0) {
                Autostat.ShowError(jData);
                return;
            }
            $("#all_graphs").show();
            Autostat.GraphData = Autostat.MakeGraphData(JSON.parse(jData.data));
            Autostat.ShowAllGraphs();
        }).catch(err => {
            Autostat.ShowError({ data: err });
        });
    },
    ShowAllGraphs: function () {
        Autostat.TotalManualEffort('bar');
        Autostat.EffortAfterCurrentAutomation('bar');
        Autostat.AverageCurrentAutomation('bar');
        Autostat.EffortAfterFutureAutomation('bar');
        Autostat.AverageFutureAutomation('bar');
        Autostat.CombineGraphsBasedOnSelection('bar');
    },
    TotalManualEffort: function (graph_type) {
        let labels = Autostat.GraphData.Program;
        let datasets = [];
        let dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
        dataset.label = "Total Manual Effort";
        dataset.data = Autostat.GraphData.TotalManualEffort;
        dataset.borderColor = "rgba(30,50,70,.2)";
        dataset.borderWidth = .5;
        dataset.backgroundColor = "rgba(220,50,35 ,.3)";
        dataset.tension = 0.2;
        datasets.push(dataset);
        Graphs.MakeChartGivenDataSets("Mookambika", datasets, "Renigunta", "TotalManualEffort", labels);
        return;
    },
    EffortAfterCurrentAutomation: function (graph_type) {
        let labels = Autostat.GraphData.Program;
        let datasets = [];
        let dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
        dataset.label = "Effort After Current Automation";
        dataset.data = Autostat.GraphData.EffortAfterCurrentAutomation;
        dataset.borderColor = "rgba(30,50,70,.2)";
        dataset.borderWidth = .5;
        dataset.backgroundColor = "rgba(50,30,70,.3)";
        dataset.tension = 0.2;
        datasets.push(dataset);
        Graphs.MakeChartGivenDataSets("", datasets, "Renigunta", "EffortAfterCurrentAutomation", labels);
        return;
    },
    AverageCurrentAutomation: function (graph_type) {
        let labels = Autostat.GraphData.Program;
        let datasets = [];
        let dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
        dataset.label = "Average Current Automation";
        dataset.data = Autostat.GraphData.AverageCurrentAutomation;
        dataset.borderColor = "rgba(30,50,70,.2)";
        dataset.borderWidth = .5;
        dataset.backgroundColor = "rgba(120,120,125, .3)";
        dataset.tension = 0.2;
        datasets.push(dataset);
        Graphs.MakeChartGivenDataSets("", datasets, "Renigunta", "AverageCurrentAutomation", labels);
        return;
    },
    EffortAfterFutureAutomation: function (graph_type) {
        let labels = Autostat.GraphData.Program;
        let datasets = [];
        let dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
        dataset.label = "Effort After Future Automation";
        dataset.data = Autostat.GraphData.EffortAfterFutureAutomation;
        dataset.borderColor = "rgba(30,50,70,.2)";
        dataset.borderWidth = .5;
        dataset.backgroundColor = "rgba(0,0,235,.3)";
        dataset.tension = 0.2;
        datasets.push(dataset);
        Graphs.MakeChartGivenDataSets("", datasets, "Renigunta", "EffortAfterFutureAutomation", labels);
        return;
    },
    AverageFutureAutomation: function (graph_type) {
        let labels = Autostat.GraphData.Program;
        let datasets = [];
        let dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
        dataset.label = "Average Future Automation";
        dataset.data = Autostat.GraphData.AverageFutureAutomation;
        dataset.borderColor = "rgba(30,50,70,.2)";
        dataset.borderWidth = .5;
        dataset.backgroundColor = "rgba(20,250,35,.3)";
        dataset.tension = 0.2;
        datasets.push(dataset);
        Graphs.MakeChartGivenDataSets("", datasets, "Renigunta", "AverageFutureAutomation", labels);
        return;
    },
    GrahsToInclude: function (e, GraphToInclude) {
        let IncludedGraphsForComparativeStudies = [];
        if ($("#Check_TotalManualEffort").is(":checked")) IncludedGraphsForComparativeStudies.push("TotalManualEffort");
        if ($("#Check_EffortAfterCurrentAutomation").is(":checked")) IncludedGraphsForComparativeStudies.push("EffortAfterCurrentAutomation");
        if ($("#Check_AverageCurrentAutomation").is(":checked")) IncludedGraphsForComparativeStudies.push("AverageCurrentAutomation");
        if ($("#Check_EffortAfterFutureAutomation").is(":checked")) IncludedGraphsForComparativeStudies.push("EffortAfterFutureAutomation");
        if ($("#Check_AverageFutureAutomation").is(":checked")) IncludedGraphsForComparativeStudies.push("AverageFutureAutomation");
        Autostat.IncludedGraphsForComparativeStudies = IncludedGraphsForComparativeStudies;
        Autostat.CombineGraphsBasedOnSelection(Autostat.CurrentTypeForComparativeStudies);
    },
    CombineGraphsBasedOnSelection: function (graph_type) {
        let labels = Autostat.GraphData.Program;
        let datasets = [];
        let dataset = {};
        Autostat.CurrentTypeForComparativeStudies = graph_type;
        Autostat.IncludedGraphsForComparativeStudies.forEach((item, index) => {
            switch (item) {
                case "TotalManualEffort":
                    dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
                    dataset.label = "Total Manual Effort";
                    dataset.data = Autostat.GraphData.TotalManualEffort;
                    dataset.borderColor = "rgba(30,50,70,.2)";
                    dataset.borderWidth = .5;
                    dataset.backgroundColor = "rgb(220,50,35)";
                    dataset.tension = 0.2;
                    datasets.push(dataset);
                    break;

                case "EffortAfterCurrentAutomation":
                    dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
                    dataset.label = "Effort After Current Automation";
                    dataset.data = Autostat.GraphData.EffortAfterCurrentAutomation;
                    dataset.borderColor = "rgba(30,50,70,.2)";
                    dataset.borderWidth = .5;
                    dataset.backgroundColor = "rgb(50,30,70)";
                    dataset.tension = 0.2;
                    datasets.push(dataset);
                    break;

                case "AverageCurrentAutomation":
                    dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
                    dataset.label = "Average Current Automation";
                    dataset.data = Autostat.GraphData.AverageCurrentAutomation;
                    dataset.borderColor = "rgba(30,50,70,.2)";
                    dataset.borderWidth = .5;
                    dataset.backgroundColor = "rgb(120,120,125)";
                    dataset.tension = 0.2;
                    datasets.push(dataset);
                    break;

                case "EffortAfterFutureAutomation":
                    dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
                    dataset.label = "Effort After Future Automation";
                    dataset.data = Autostat.GraphData.EffortAfterFutureAutomation;
                    dataset.borderColor = "rgba(30,50,70,.2)";
                    dataset.borderWidth = .5;
                    dataset.backgroundColor = "rgb(0,0,235)";
                    dataset.tension = 0.2;
                    datasets.push(dataset);
                    break;

                case "AverageFutureAutomation":
                    dataset = {}; dataset.type = graph_type;//dataset.type = 'bar';
                    dataset.label = "Average Future Automation";
                    dataset.data = Autostat.GraphData.AverageFutureAutomation;
                    dataset.borderColor = "rgba(30,50,70,.2)";
                    dataset.borderWidth = .5;
                    dataset.backgroundColor = "rgb(20,250,35)";
                    dataset.tension = 0.2;
                    datasets.push(dataset);
                    break;

            }
        });
        Graphs.MakeChartGivenDataSets("", datasets, "Renigunta", "ComparativeStudies", labels);
    },
    GetGraphData: function () {
        return $.ajax({ url: config.url_prefix + "Summary" }).then(jData => {
            if (!jData) throw "No Data Found in the Excel File";
            // let jRet = JSON.parse(jData);
            let jRet = jData;
            return jRet;
        })
    },
    MakeGraphData: function (jd) {
        let LabelsAndValues = {};
        LabelsAndValues.Program = []; LabelsAndValues.TotalManualEffort = [];
        LabelsAndValues.EffortAfterCurrentAutomation = []; LabelsAndValues.AverageFutureAutomation = [];
        LabelsAndValues.AverageCurrentAutomation = []; LabelsAndValues.EffortAfterFutureAutomation = [];

        jd.forEach((item, index) => {
            LabelsAndValues.Program.push(item.Program);
            let TotalManualEffort = parseFloat(item.TotalManualEffort);
            if (isNaN(TotalManualEffort)) TotalManualEffort = 0;
            else TotalManualEffort = Math.ceil(TotalManualEffort);
            LabelsAndValues.TotalManualEffort.push(TotalManualEffort);

            let EffortAfterCurrentAutomation = parseFloat(item.EffortAfterCurrentAutomation);
            if (isNaN(EffortAfterCurrentAutomation)) EffortAfterCurrentAutomation = 0;
            else EffortAfterCurrentAutomation = Math.ceil(EffortAfterCurrentAutomation);
            LabelsAndValues.EffortAfterCurrentAutomation.push(EffortAfterCurrentAutomation);

            let AverageCurrentAutomation = parseFloat(item.AverageCurrentAutomation);
            if (isNaN(AverageCurrentAutomation)) AverageCurrentAutomation = 0;
            else AverageCurrentAutomation = Math.ceil(AverageCurrentAutomation);
            LabelsAndValues.AverageCurrentAutomation.push(AverageCurrentAutomation);

            let EffortAfterFutureAutomation = parseFloat(item.EffortAfterFutureAutomation);
            if (isNaN(EffortAfterFutureAutomation)) EffortAfterFutureAutomation = 0;
            else EffortAfterFutureAutomation = Math.ceil(EffortAfterFutureAutomation);
            LabelsAndValues.EffortAfterFutureAutomation.push(EffortAfterFutureAutomation);

            let AverageFutureAutomation = parseFloat(item.AverageFutureAutomation);
            if (isNaN(AverageFutureAutomation)) AverageFutureAutomation = 0;
            else AverageFutureAutomation = Math.ceil(AverageFutureAutomation);
            LabelsAndValues.AverageFutureAutomation.push(AverageFutureAutomation);
        });
        return LabelsAndValues;
    },
    handleFileSelect: async function (e) {
        $("#error_info").hide();
        Header.selectedFile = e.target.files[0];
        var fd = new FormData();
        fd.append("question_file", Header.selectedFile);
        let jData = await $.ajax({
            url: config.contextPath + "Home/UploadXL",
            type: "POST",
            contentType: 'multipart/form-data',
            data: fd,
            contentType: false,
            processData: false,
        });

        if (!jData) {
            Autostat.ShowError(jdata);
            return;
        }
        let jRetVal = JSON.parse(jData);
        if (jData.WhatHappened < 0) {
            Autostat.ShowError(jdata);
            return;
        }
        $("#all_graphs").show();
        Autostat.GraphData = Autostat.MakeGraphData(JSON.parse(jRetVal.data));
        Autostat.ShowAllGraphs();
    }
}