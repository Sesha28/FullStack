﻿var UserProjectAssociation = {
    uid: null, pid: null,
    start_action: function (tag, data) {
        return new TemplateRenderer(data, tag, "~/Scripts/Components/UserProjectAssociation/UserProjectAssociation.html", null, false).start_action().
            then(vals => {
                UserProjectAssociation.doAutoComplete_User("#ch_user");
                UserProjectAssociation.doAutoComplete_Project("#ch_project");
                return vals + "User Project Association successfully placed";
            });
    },
    doAutoComplete_User: function (jid) {
        $(jid).autocomplete({
            source: async (req, resp) => resp(JSON.parse(await $.ajax({ url: config.contextPath + 'Home/AutoCompleteEmployees?&term=' + req.term }))),
            minLength: 2, //wait for atleast 3 input characters
            delay: 800, // wait for 800 ms before you start pounding the server
            focus: function (event, ui) {
                event.preventDefault();
                $(jid).val(ui.item.label);
            },
            select: (e, ui) => {
                if (!ui.item.label) return false;
                e.preventDefault();
                UserProjectAssociation.uid = ui.item.value;
                $(jid).val(ui.item.label);
                return true;
            }
        });
    },
    doAutoComplete_Project: function (jid) {
        $(jid).autocomplete({
            source: async (req, resp) => resp(JSON.parse(await $.ajax({
                url: config.contextPath + 'Home/AutoCompleteAllProjects?&term=' + req.term,
                data: { "user_id": LoggedInUser.id }
            }))),
            minLength: 2, //wait for atleast 3 input characters
            delay: 800, // wait for 800 ms before you start pounding the server
            focus: function (event, ui) {
                event.preventDefault();
                $(jid).val(ui.item.label);
            },
            select: (e, ui) => {
                if (!ui.item.label) return false;
                e.preventDefault();
                UserProjectAssociation.pid = ui.item.value;
                $(jid).val(ui.item.label);
                return true;
            }
        });
    },
    AssociateUserToProject: async function (event, user_name, project_name) {
        let uid = UserProjectAssociation.uid; let pid = UserProjectAssociation.pid;
        //alert("User: " + user_name + " Project: " + project_name + " User ID: " + uid + " Project ID: " + pid);
        if (!uid || !pid || !user_name || !project_name) return alert("Something Wrong, either user or/and project is null/empty");
        let result = await $.ajax({ url: config.contextPath + "Home/AssociateUserToProject", data: { "user_id": uid, "project_id": pid } });
        alert(result);
    }
}