﻿var Graphs = {
    BackgroundPlugin: {
        id: 'background', //what is the name of yur plugin, this needs to be refered in th options below
        beforeDraw: (chart, args, options) => {
            const { ctx } = chart;
            ctx.save();
            ctx.globalCompositeOperation = 'destination-over';
            ctx.fillStyle = options.color ? options.color : 'yellow';
            ctx.fillRect(0, 0, chart.width, chart.height);
            ctx.restore();
        }
    },
    MakeDummyGraph: function (canva_id) {
        var labels = ["Identified", "Defined", "Committed", "Covered", "Obsolete", "Rejected", "Empty", "Demonstrated"];
        var datasets = [];
        let dataset = {}; dataset.type = 'bar'; 'line';//'scatter'  'bar'; 'polarArea' , 'radar'
        dataset.label = "This ChartJS is easy";
        dataset.data = [10, 50, 170, -100, 20, -80, 100, 39];
        dataset.borderColor = "rgba(30,50,70,.2)";
        //dataset.borderColor = "magenta";
        if (dataset.type === 'line') dataset.borderWidth = 5.5;
        else dataset.borderWidth = .5;
        dataset.backgroundColor = "rgb(220,50,35)";
        dataset.tension = 0.2;
        dataset.last_known_entry = "A Man with no Name";
        dataset.ramba = "Urvashi";
        datasets.push(dataset);
        Graphs.MakeChartGivenDataSets("Labamba", datasets, "Renigunta", canva_id, labels);
    },
    MakeChartGivenDataSets: function (title, datasets, custom_data, canva_id, labels) {
        const kanvas = document.getElementById(canva_id);
        let chart = Chart.getChart(canva_id); if (chart) chart.destroy();
        new Chart(kanvas, {
            data: {
                labels: labels,
                datasets: datasets,
                custom_data: custom_data,
                title: title
            },
            options: {
                //aspectRatio: 1,
                plugins: {
                    title: {
                        display: true,
                        position: "top",
                        align: "center" ,
                        text: title,
                        color: "Blue",
                    },
                    background: { //you dont get this by default, background color needs the plugin dance, 
                        color: 'white',//'cyan'
                    },
                    //datalabels: {
                    //    display: false,
                    //},
                    datalabels: {
                        anchor: "end",
                        align: "end",
                        offset: 1,
                        color: 'blue',
                        font: {
                            weight: 'normal',
                            size: "8px",
                        },
                        formatter: function (value, context) {
                            return "{" + value + "}";// + " - " + context.dataset.ramba;
                            //if (context.datasetIndex !== 0) return null;
                            //if (!cur_project.is_legacy) return value + "%\n" + entry_log[Graphs.sample_modern[context.dataIndex]] + " / " + entry_log.Total;
                            //else return value + "%\n" + entry_log[Graphs.sample_legacy[context.dataIndex]] + " / " + entry_log.Total;
                        }
                    },
                    //tooltip: {
                    //    callbacks: {
                    //        label: function (context) {
                    //            if (!cur_project.is_legacy) return ["  Completed " + context.formattedValue + "%", "  " + entry_log[Graphs.sample_modern[context.dataIndex]] + " Out of " + entry_log.Total];
                    //            return ["  Completed " + context.formattedValue + "%", "  " + entry_log[Graphs.sample_legacy[context.dataIndex]] + " Out of " + entry_log.Total];
                    //        }
                    //    }
                    //}
                },
                animations: {
                    tension: {
                        duration: 1000,
                        easing: 'linear',
                        from: 1,
                        to: 0,
                        loop: true
                    },
                    //borderWidth: {
                    //    duration: 1000,
                    //    easing: 'linear',
                    //    from: 1,
                    //    to: 10,
                    //    loop: true
                    //}
                },
                scales: {
                    x: {
                        type: 'category',
                        border: {
                            display: true
                        },
                        grid: {
                            display: true,
                            drawOnChartArea: true,
                            drawTicks: true,
                        }
                    },
                    y: {
                        border: {
                            display: false
                        },
                        grid: {
                            color: function (context) {
                                if (context.tick.value > 0) {
                                    return "rgba(115,205,170, .1)";
                                } else if (context.tick.value < 0) {
                                    return "red";
                                }
                                return '#000000';
                            },
                            lineWidth: 4.6,
                        },
                    }
                }
            }
        });
    },
}