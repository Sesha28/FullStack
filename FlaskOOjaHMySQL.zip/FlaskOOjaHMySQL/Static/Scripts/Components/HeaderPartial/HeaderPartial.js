﻿var HeaderPartial = {
    start_action: function (tag, data) {
        return $.ajax({ url: config.contextPath + "Home/HeaderPartial" }).then(jTemplate => {
            return new TemplateRenderer(data, tag,
                null, //templatePath
                jTemplate, //HTMLTemplate
                null, //templateEngine
                false //cacheCompiledTemplate
            ).start_action();
        });
        //return new TemplateRenderer(data, tag,
        //    "~/Home/HeaderPartial", //templatePath
        //    false, //templateEngine - Use handleBars
        //    false //cacheCompiledTemplate
        //).start_action();

    }
}