﻿var Header = {
    myModal: null,
    TheIcon: null,
    log_off: `<div class="text-centered">
                 <button class="me-auto btn btn-outline-success border-4 rounded-circle " data-bs-toggle="modal" data-bs-target="#LogInModal">                
                    <i class="bi bi-cart4"></i>
                </button>
                <small class="d-block" id="welcome_message"></small>
              </div>`,
    log_in: '<a class="btn btn-outline-success" href="_VD_Home/Login#log_me_in" >Click here to access</a>',
    start_action: function (jData, tag) {
        return (new TemplateRenderer(jData, tag, "~/Scripts/Components/Header/Header.html", null, false, true).start_action()).
            then(async (value) => {
                //$(".nav-link").on("click", (e) => TakeNavLinkAction($(e.target)));
                //$(document).on("click", ".nav-link", e => Header.TakeNavLinkAction($(e.target)));
                Header.ObserverURlChange();
                // let current_href = $(a[zora]).attr('href').replace
                // $(a[zora]).attr({'href': })
            });
    },
    ObserverURlChange: function () {
        let previousUrl = '';
        const observer = new MutationObserver((mutationList, observer) => {
            if (location.href !== previousUrl) {
                previousUrl = location.href;
                // alert(`URL changed to `+ document.location.href);
                Header.HighlightNavigationMenu();
                Header.ManageUserInfo();
            }
        });
        const mutation_config = { subtree: true, childList: true };
        observer.observe(document, mutation_config);
    },
    ManageUserInfo: function () {
        $.ajax({ url: config.url_prefix + 'GetUser' }).
            then(async (jData) => {
                if (jData) {
                    $("#user_name").text(jData); $("#user_mail").text(jData); $("#user_role").text("Admin");
                    $("#log_off").html("Welcome <b>" + jData + "</b>").show();
                    let profile_path = await $.ajax({ url: config.url_prefix + "GetProfileImage" })
                    let p_p = profile_path + "?" + Math.random();
                    $("#prof_img").attr({ "src": p_p })
                }
            })
            .catch((aa, bb, cc) => {
            let k = 90;
            k += 90;
        })    
    },
    TakeNavLinkAction: function (link) {
        $(".nav-link").removeClass("active");
        link.addClass("active");
    },
    HighlightNavigationMenu: function () {
        let url = window.location.pathname; // Returns path only (/path/example.html)
        let current_link = "a[class*='nav-link'][href='_URL_']".replace(/_URL_/, url);
        Header.TakeNavLinkAction($(current_link));
    },
    SetUserName: function (user_name) {
        Header.TheIcon.SetUserDetails();
    },
    handleFileSelect: async function (e) {
        Header.selectedFile = e.target.files[0];
        var fd = new FormData();
        fd.append("yg_file", Header.selectedFile);
        let sumbit_ans_result = await $.ajax({
            url: config.url_prefix + "SubmitProfileImage",
            type: "POST",
            contentType: 'multipart/form-data',
            data: fd,
            contentType: false,
            processData: false,
        });
        if (sumbit_ans_result) $("#prof_img").attr({ "src": sumbit_ans_result + "?" + Math.random() });
    }
}
