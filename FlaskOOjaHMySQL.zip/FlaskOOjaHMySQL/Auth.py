import os
import Globals
import App
import datetime
from functools import wraps
from flask import Flask, abort, render_template, request, Response, session, redirect, jsonify

from LogInModel import ConnectionModel


prefix = Globals.prefix
UsersParallelConnections = {}

# def CleanStaleSession():
#     if ('mail' in session):
#         mail = session['mail']
#         if (mail in UsersParallelConnections):
#             cm = UsersParallelConnections[mail]
#             difference = datetime.datetime.now() - cm.last_accessed_time
#             if (difference.total_seconds() >= Globals.sesssion_seconds):
#                 cm.isOccupied = 0
#         else:
#             pass
#     else:
#         pass


def VerifyMailPWD(mail, pwd):
    MatchedUsers = [u for u in Globals.Users if u["mail"] ==
                    mail and u["pwd"] == pwd]
    return len(MatchedUsers) == 1


def ModfyLastAccessedTime():
    if 'mail' not in session:
        return
    mail = session['mail']
    CurrentConnection = [con for con in UsersParallelConnections[mail]
                         if con.ConnectionID == session['ConnectionID']]
    for cur_con in CurrentConnection:
        cur_con.last_accessed_time = datetime.datetime.now()


def CleanStaleUserConnections(mail):
    # if (mail not in session):
    #     return
    global UsersParallelConnections
    if (mail not in UsersParallelConnections):
        print("%%%%%%%%%%%%%%%%%%%%%%%%%% ", mail,
              " Not in UsersParallelConnections %%%%%%%%%%%%%%%%%%%%%%%%%% ")
        return
    StaleConnectionsForThisMail = [con for con in UsersParallelConnections[mail]
                                   if (datetime.datetime.now() - con.last_accessed_time).total_seconds() >= Globals.sesssion_seconds]
    if (len(StaleConnectionsForThisMail) > 0):
        print("Length = ", len(StaleConnectionsForThisMail),
              "Found it : - ", StaleConnectionsForThisMail[0].print(), "\n Need to remove all of Them")
        for StaleConnection in StaleConnectionsForThisMail:
            UsersParallelConnections[mail].remove(StaleConnection)
    else:
        print("************ len(StaleConnectionsForThisMail) is ZERO ************")


def isLoggedIn(theMethod):
    @wraps(theMethod)
    def wrap(*args, **kwargs):
        global UsersParallelConnections
        if 'mail' not in session:
            return redirect(prefix + '/Login')
        else:
            ModfyLastAccessedTime()
            return theMethod(*args, **kwargs)
    return wrap


def isLoggedInAjax(theMethod):
    @wraps(theMethod)
    def wrap(*args, **kwargs):
        if 'username' not in session:
            abort(404)
            return
        else:
            return theMethod(*args, **kwargs)
    return wrap

@App.app.route(prefix + '/doLogin', methods=['POST'])
# Remember this is ajax post
def doLogin():
    global UsersParallelConnections
    if (request.method != "POST"):
        return "CowDung"
    mail = request.form['mail']  # User auth to be done here
    pwd = request.form['pwd']  # User auth to be done here
    if VerifyMailPWD(mail,pwd) == False:
        return "LogInFailed"
    # After user auth with database is successfull do the below
    if mail in UsersParallelConnections:
        CleanStaleUserConnections(mail)
        ExistingConnectionsForThisMail = UsersParallelConnections[mail]
        if (len(ExistingConnectionsForThisMail) >= Globals.max_parallel_connections):
            return "AlreadyLoggedIn"
        else:
            # scope to accommodate this connection esists
            session.permanent = True
            session['mail'] = mail
            con = ConnectionModel()
            ExistingConnectionsForThisMail.append(con)
            session['ConnectionID'] = con.ConnectionID
            return "RealLogIn"
    else:
        session.permanent = True
        session['mail'] = mail
        con = ConnectionModel()
        UsersParallelConnections[mail] = []
        UsersParallelConnections[mail].append(con)
        session['ConnectionID'] = con.ConnectionID
        return "RealLogIn"

    # dict = {'Name':"Priyanka",'Age':40,'Addres':"New York"}
    return "RealLogIn"


@App.app.route(prefix + '/LogOff')
def LogOff():
    global UsersParallelConnections
    if 'mail' not in session or 'ConnectionID' not in session:
        return redirect(prefix)
    mail = session['mail']
    ConnectionID = session['ConnectionID']
    AllUserConnectionsForThisMail = [con for con in UsersParallelConnections[mail]
                                     if con.ConnectionID == ConnectionID]
    for UserConnection in AllUserConnectionsForThisMail:
        UsersParallelConnections[mail].remove(UserConnection)
    session.clear()
    return redirect(prefix)

@App.app.route(prefix + '/GetTime')
def GetTime():
    ss = App.app
    return datetime.datetime.now().strftime("%m/%d/%Y, %H:%M:%S")

@App.app.route(prefix + '/GetUser')
def GetUser():
    return session['mail']

@App.app.route(prefix + '/SubmitProfileImage', methods=['POST'])
# @isLoggedIn
def SubmitProfileImage():
    if request.method != "POST":
        return
    # print("In POST method")
    files = request.files.getlist("yg_file")
    # print(files)
    saveFolder = App.app.root_path + \
        Globals.uploaded_folder_for_profile_pic + "\\" + session['mail']
    if os.path.isdir(saveFolder) == False:
        os.mkdir(saveFolder)
    for file in files:
        # print(file.filename)
        # file.save(os.path.join(saveFolder, file.filename))
        file.save(os.path.join(saveFolder, session['mail'] + ".jpg"))
    return "/static/Content/Images/" + session['mail'] + "/" + session['mail'] + ".jpg"


@App.app.route(prefix + '/GetProfileImage', methods=['GET'])
# @isLoggedIn
def GetProfileImage():
    saveFolder = App.app.root_path + \
        Globals.uploaded_folder_for_profile_pic + "\\" + session['mail']
    profileImage = os.path.join(saveFolder, session['mail'] + ".jpg")
    if os.path.isfile(profileImage) == True:
        p_p = "/static/Content/Images/" + session['mail'] + "/" + session['mail'] + ".jpg"
        return p_p
    else:
        return "/static/Content/Images/OOjaH.ico"