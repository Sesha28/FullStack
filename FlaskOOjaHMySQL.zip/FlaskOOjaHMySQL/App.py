from datetime import timedelta
from flask import Flask
from flask_cors import CORS
import Globals

app = Flask(__name__, static_folder='static')
app.secret_key = 'F12Zr47j\3yX R~X@H!jmM]Lwf/,?KT'
app.json.sort_keys = False
app.permanent_session_lifetime = timedelta(seconds=Globals.sesssion_seconds)
CORS(app)  # This will enable CORS for all routes