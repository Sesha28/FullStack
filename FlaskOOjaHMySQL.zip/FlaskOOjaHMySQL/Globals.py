# json_path = r"C:\WOI\Code\VC Days are here again\Ode to Duty\Web\ASP.NET\Cariappa\1.json"
json_path = r"C:\WOI\Code\VC Days are here again\Ode to Duty\Web\ASP.NET\Cariappa\2.json"
prefix = "/Menka"
database = "vnvstat"
user = "postgres"
password = "root@123"
host = "127.0.0.1"
port = "5432"
database_mysql = "sakila"
user_mysql = "root"
password_mysql = "root@123"

domain = "127.0.0.1"
web_port = 1857
max_parallel_connections = 1
sesssion_seconds = 10000000
uploaded_folder_for_profile_pic = r"\Static\Content\images"

User_1 = {
    "mail": "sesha.sai",
    "pwd": "123"
}

User_2 = {
    "mail": "nidesh",
    "pwd": "123"
}
Users = [User_1, User_2]
