import random
from random import choice
from string import ascii_uppercase
from flask import Flask,abort, render_template, request, Response, send_from_directory, session, redirect, jsonify
import App
import Globals
import Auth
import os

prefix = Globals.prefix

@App.app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(App.app.root_path, 'static/Content/Images'), 'OOjaH.ico', mimetype='image/vnd.microsoft.icon')


@App.app.route(prefix + '/')
# @Auth.isLoggedIn
def HomePage():
    session['mail'] = "Mookambika"
    # if 'username' not in session:
    #   return redirect('/ShowLogIn')
    dict = {'phy': 50, 'che': 60, 'maths': 70, 'English': 90}
    # return render_template('Home_page.html', result=dict)
    return render_template('Home_page.html', result=dict, prefix=prefix)


@App.app.route(prefix + '/About')  # ,methods = ['POST', 'GET'])
# @Auth.isLoggedIn
def About():
    return render_template('about_page.html', result="Katrina Kaif", prefix=prefix)


@App.app.route(prefix + '/Login')  # ,methods = ['POST', 'GET'])
def Login():
    return render_template('Login_page.html', result="Katrina Kaif", prefix=prefix)
