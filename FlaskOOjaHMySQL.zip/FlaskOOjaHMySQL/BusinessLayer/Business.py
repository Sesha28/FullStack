from DataAccessLayer.DataAccessLayer import DataAccess
from SQLStatements.SQLStatements import AllSQLStatements

class Business:
    @staticmethod
    def GetAllActors():
        return DataAccess.GetRecords(AllSQLStatements.GetAllActors)        

    @staticmethod
    def GetActorsWithFirstName(first_name):
        return DataAccess.GetRecordsWithParam(AllSQLStatements.GetActorsWithFirstName, (first_name,))

    @staticmethod
    def GetActorsWithFirstNameLike(search_term):
        return DataAccess.GetRecordsWithParam(AllSQLStatements.GetActorsWithFirstNameLike, (f"%{search_term}%",))
    
    
    @staticmethod
    def InsertActor(first_name, last_name):
        sql = AllSQLStatements.InsertActor
        params = (first_name,last_name)        
        #DataAccess.InsertRecordsWithParam(sql, params)
        return "Good Boy"
