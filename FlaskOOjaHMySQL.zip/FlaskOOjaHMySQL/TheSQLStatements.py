class TheSQLStatements:
    GetAllActors = "SELECT * FROM actor"
    GetActorsWithFirstName = "SELECT * FROM actor WHERE first_name = %s"
    GetActorsWithFirstNameLike = "SELECT * FROM actor WHERE first_name LIKE %s"

