import datetime
import uuid


class ConnectionModel:
    def __init__(self):
        self.ConnectionID = str(uuid.uuid4())
        self.isOccupied = 1
        self.last_accessed_time = datetime.datetime.now()

    def print(self):
        return ("ConnectionID = " + self.ConnectionID +  " , isOccupied = " +
                str(self.isOccupied) + ", last_accessed_time = " + self.last_accessed_time.strftime("%m/%d/%Y, %H:%M:%S"))
      