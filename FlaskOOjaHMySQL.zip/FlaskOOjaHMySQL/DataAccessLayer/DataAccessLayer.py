import mysql.connector
import Globals
class DataAccess:
    
    staticmethod
    def  get_db_connection_MySQL():
        conn = mysql.connector.connect(
            database = Globals.database_mysql,
            user = Globals.user_mysql,
            password = Globals.password_mysql,
            host = Globals.host,        
        )
        return conn

    staticmethod
    def GetRecords(sql):
        conn =  DataAccess.get_db_connection_MySQL()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(sql)
        actors = cursor.fetchall()
        cursor.close()
        return actors
    
    staticmethod
    def GetRecordsWithParam(sql, params):
        conn =  DataAccess.get_db_connection_MySQL()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(sql, params)
        actors = cursor.fetchall()
        cursor.close()
        return actors
    
    staticmethod
    def InsertRecordsWithParam(sql, params):
        conn =  DataAccess.get_db_connection_MySQL()
        cursor = conn.cursor()
        cursor.execute(sql, params)
        conn.commit()        
        cursor.close()
        return True
