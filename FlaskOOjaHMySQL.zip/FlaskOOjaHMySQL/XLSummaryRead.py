import json
import pandas
import math

def ReadSummary(XLPath):
    sheet_name = "Master Sheet"
    sheet_name = "Summary"
    cols='C:H' #usecols=cols
    # Read excel document
    excel_data_df = pandas.read_excel(XLPath, sheet_name=sheet_name,skiprows=1, header=0, usecols=cols)#, nrows=19 )
    #print(excel_data_df)

    #find first row where the first column is empty
    ind = 0
    for index, row in excel_data_df.iterrows():
        # if math.isnan(row.iloc[0]) :
        if not (row.iloc[0]) :
            print("First Empty Index = " , ind)
            break
        else :
            ind = ind + 1    
            #print("Not Empty Index = ", ind)
        #print(row.iloc[0])

    the_df = excel_data_df.head(ind)
    the_df = the_df.rename(columns={'Average Current Automation %': 'AverageCurrentAutomation', 
                                    'Average Future Automation %': 'AverageFutureAutomation', 
                                    'Effort after Current Automation in Hrs':'EffortAfterCurrentAutomation',
                                    'Program':'Program',
                                    'Effort after Future Automation in Hrs':'EffortAfterFutureAutomation',
                                    'Total Manual effort in Hrs ':'TotalManualEffort'})
    # print(the_df)
    the_json_string = the_df.to_json(orient='records' , indent=2)
    # Convert excel to string 
    # (define orientation of document in this case from up to down)
    # return the_json_string
    return json.loads(the_json_string)
    