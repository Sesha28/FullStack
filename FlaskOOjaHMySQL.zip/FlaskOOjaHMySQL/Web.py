# import random
# import XLSummaryRead
# import os
# import database
# import graph
# from random import choice
# from string import ascii_uppercase
# from flask import Flask, abort, render_template, request, Response, session, redirect, jsonify
# from functools import wraps
# from tkinter import messagebox
# from flask import send_from_directory
# from flask_cors import CORS

import Globals
import App
#################################### Import All Coding for all Routes else nothing will work #################################################
import PageControllers
import Ajax
#################################### Import All Coding for all Routes else nothing will work #################################################

#################################### Reflection Example#################################################
# import importlib
# module = importlib.import_module('my_package.my_module' or 'fileName of the .py without the extension')
# my_class = getattr(module, 'MyClass')##################################################################
# my_instance = my_class()###############################################################################
# if method is static####################################################################################
# myMethod = getattr(module, 'theMethod')################################################################
# myMethod()#############################################################################################
#################################### Reflection Example##################################################

if __name__ == '__main__':
    # messagebox.showinfo( "button 1 clicked",'So long mate')
    App.app.run(port=Globals.web_port, host=Globals.domain, debug=True)
