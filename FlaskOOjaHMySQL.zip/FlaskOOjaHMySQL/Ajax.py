import random
from random import choice
from string import ascii_uppercase
from flask import Flask, render_template, request, Response,session,redirect,jsonify
from flask import abort
import App
import  Globals
import DataAccessLayer.DataAccessLayer as DataAccessLayer
from BusinessLayer.Business import Business
prefix = Globals.prefix
json_path = Globals.json_path

@App.app.route(prefix + '/AllActors')
def GetAllActors():
    return Business.GetAllActors()

@App.app.route(prefix + '/ActorsWithFirstName')
def ActorsWithFirstName():
    first_name = request.args.get('first_name')
    actors = Business.GetActorsWithFirstName(first_name)
    return actors

@App.app.route(prefix + '/ActorsWithFirstNameLike')
def ActorsWithFirstNameLike():
    first_name = request.args.get('first_name')
    actors = Business.GetActorsWithFirstNameLike(first_name)
    return actors

@App.app.route(prefix + '/Ajax')
def AjaxCall():
   theList = []
   for i in range(0,100):
      dito = {'Name':'Name_'+str(i*2),'Bage':str(random.choice(range(0,1000))),'Address':''.join(choice(ascii_uppercase) for i in range(12))}
      theList.append(dito)
   return jsonify(theList)


# url ~/Menka/InsertActor?first_name=John&last_name=Abraham
@App.app.route(prefix + '/InsertActor')
def InsertActor():
    first_name = request.args.get('first_name')
    last_name = request.args.get('last_name')
    if not first_name or not last_name:
        return "First name and last name are required"

    what_happened = Business.InsertActor(first_name, last_name)
    return what_happened
