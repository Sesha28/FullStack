class AllSQLStatements:
    GetAllActors = "SELECT * FROM actor"
    GetActorsWithFirstName = "SELECT * FROM actor WHERE first_name = %s"
    GetActorsWithFirstNameLike = "SELECT * FROM actor WHERE first_name LIKE %s"
    InsertActor = "INSERT INTO actor (first_name, last_name) VALUES (%s, %s)"
