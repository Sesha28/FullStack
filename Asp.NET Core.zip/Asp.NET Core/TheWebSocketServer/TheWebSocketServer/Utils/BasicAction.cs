﻿namespace Utils
{
    public static class BasicAction
    {
        public static readonly Random rand = new();
        public static readonly string nsAppreferencesFolder = "TheWebSocketServer.AppReferences.";
    }
}
