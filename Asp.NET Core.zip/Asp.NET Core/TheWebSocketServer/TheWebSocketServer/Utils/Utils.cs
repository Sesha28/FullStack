﻿using System.Text;

namespace Utils
{
    public static class Helper
    {
        public static string ProcessExceptionHTML(this Exception ex)
        {
            StringBuilder strBuild = new StringBuilder(5000);
            Exception inner = ex;
            Enumerable.Range(0, 10).All(x =>
            {
                if (x == 0)
                {
                    strBuild.Append("<div class='box' style='color:red;font-weight:bolder;font-family:calibri;background-color:white;'><img src='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhQUEBAREhUSFBoaGBcYGRYWGhYYFRMXFxobGx0bHSggJCYqHhgWITIhJykrLjAuGCAzPTMtNygtLisBCgoKDg0OGxAQGysjICY3Lyw3NzEvLTUxNzM1LzcuNTcwMDAtMC0xKzctNys3LSsrNTU3LTc3Mi03LS01Ly8tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAgYEBQcBAwj/xABCEAACAQMDAQYEBAIHBQkAAAABAgMABBEFEiExBhMiQVFxByMyYRSBkbEzUhVCQ2KCofBjcoPB0SQlNESSosLS8f/EABoBAQADAQEBAAAAAAAAAAAAAAABAwQCBQb/xAAvEQEAAgIBAgMGBgIDAAAAAAAAAQIDEQQhMQUSE0FRYXGR8DKBobHB4SJCBhQj/9oADAMBAAIRAxEAPwDt/T2/apUqPT2/aglSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBUSfIUJ8hXoFB53Y/0TXlTpQKUpQR6e37VKlR6e37UEqUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKiT5ChPkK9AoAFe0pQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKiT5ChPkK9AoAFe0pQKUpQKUpQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQKVBpQMeZPQDGSMgE+wyKxGuun9bP8p5f6eY/F0Gef9ZDM3jjkc9PvUWmUDOR5+Y5xnI/yP6VqbvU1RGeSRQoUlmDBQ4AJ+US4Ax/Wqm6x8U9MRij3HfnOG7pHZcYfaYmJ2hhlctnH/ILle9prRQf+8LOM5xl5IyARnIPjHoeM+VQj1WdQHZIrqE/2tsSWHUk90S2QB/I7MfJapMXxj09s9488RbcGHdt9GJNmzYxw53JljxwftVgtHs7rdPZzIH85bZgpbiUohXOGkwASsin1GOCAuEMquoZCGVhkEedTrW2F02CJAu5TyyAhH5b6QScNxypJIPmRgnYK4P8Ar/KglSlKBUSfIUJ8hXoFAAr2lKBSlKBSlKBSlKBSlKBSlKBSlKBSlKCPT2/avlLL79R0zk5ZOR/d55NSlfHr1A4BJySMeR455PlWlmnK87ZPAyg92rFlYm3ISHMeGhOcO/Qc8jB2B93uTxnceVzs3EknuOYeOY/F4j5c/etHrOuR28LzXD7I41BdoyQSdsO0WZPDIScP9yax4pZwfmQrGqNGoNuzu8an8L4bUG1AMJwu/BOMtyMDGmXS0vdQtbaSNNlmguZERR+HQ7I44Y7VtikxlgzMOQWjI8sUHmk9jZ9XK3WsFooD4oLGMsiqpHDP5gkc4GDz1H010bSdEtrVdttbwwgfyIq59yBk+5rYUoPlc2ySKVkRHU9QwDA/kaoev/C2BmFxpjf0fdJko0f8MnBGCnQZBIyuOvQ9K6DSg572Y7RSSNJb3kXcXluPmxj6XXxHv7fAJZ2Jq3W05yOD68hsbcr9Xh/i/wB2q/8AEjSV2RX6jEuntvLgAt3BG2bGQRuVC0ikg4ZPuakl0qYLhUH8TLgqhTcnz5GMAAuvPus/9QFsgkyB15GRkHOMD6uODz0r6E+Qqu6LqsU+38PJHNuVXyDncvycyTYiG2Yc4jOOnljw761fKr9WCoI3AqxGB9QIG089CP8AoA+oFe0pQKUpQKUpQKUpQKUpQKUpQKUpQKUpQK8Y1Xu3HayLTbfvXUySO2yGJfqlkPQdDgepx+pIBp1p2N1PUvm6vfzWqPytrbHZsB6bzyM/Yhz9x0oL9eMcgnePGqlghZtzPH8sfJOYm/rSeQzyMZXn3aLUbl7mLTdMVIrruwZZNg2WUGyEGKBjEuYiVXnBycDjjbsx8KoojvsdQv7aUKQGLrKhBxkOjDDDIGVyAce1OwOmXFvqN2L1I1c20CwNGAsTQwl0IiGBtAzFlDyCR5EUGvtvg93aoy6tfLNGu1JFICpx0VM7gvTwh+grI+FthcW15fW95sMkMFssRRVRGhDXGGjVQAAScn+8Wq6drNbWxtJrlgG7pCVUnbuY8KufuSK49bXt1LILmfX2tpSuPl2U7wom7cE3lFQqD5+L3PWomYjuO8UrRdj9SaeAF7y1vGXjvYOA3+8mTtP5/kK2OrapDbRmW4lWJAcZbzJ6ADqSfIDJNSMylUybtLeXH/grVYIz/b3e4Ej1SBSHP+Nk9qxjo88nN1qd7IfSJltUHsIgHx7ua87P4rxcM6m25+HX+llcVpb7ttf91aOqwmeS5+RFCP7R5VIwfQBdzMfJVY1TdG+EML5k1WV7ueRi8gUmKJXfG4qE2kk4GW4zjOKzpOzjKQ9rf3sUqA7Wkla5QEjHKTbhz9sH719+wvbWSaeSw1GNIbyHJGzIjnQc7kz54wceY54wQvfE8Qw8rcY56x7J7otSa92Lqnwc09gGs++spkIZJUkkfa6nKkh2J4OD4Sp461sexOq3Pey2d+qi8hAcuoAS7iYoiz5C/UAu3HH/ANbDr2uw2aBpmOXO1I0BeSVv5UQck/5DzwKpes3+pTSRz2+m2kbRBgnfzbnKsVbDKg2jxJG2N5wUHNaMvIxYtepaI375cxWZ7OhvLgZwxz6A5/SseLU4mYJu2ueiuGjZsddoYAt7jNcqX4uXdo6x6rphT+9G2C2OpUHKN+T10PRdbstUgJhZJ043IwwyN1G5TyDkZB+2QatraLRus7hDfUrRRzPZsqTO0tu7BY5XO54mY4WOVjywJIVZDznAYkkMd7UhSlKBSlKBSlKBSlKBSlKBSlVWftsjMy2VtcXu0kGSPYkIIOCBLIyq2Ofo3dK4vkpSPNeYiPimI21MNj+N16aSUbotKijSJT07+de8L+4Uge+w+VdArnugdqIYLy4W9jlspb+dHjEu0o223iiwJUJTO5DwSPqHmRU+096by6a0DEW1uB34DFO/lddwiLDnaqFWYA8lwPI1Xk5OOmKcu91+H8JiszOl1j1KFm2rPEW/lDqT+mc193QZDEDK5wfTI5rjOo6jpf4lLA6fbhyQpYRRbUcjITcBuyR5jzI++MTtVd3enSi2tZ5Ht9RiMSxyO0n4d3IizE7HcMbwQM+v2NZeP4jGS8UvWazMbjfth1bHMLjZML+U3s4DRKxFnGeVWNTjvyDxvcgkHyTbjqa+Wt9u7W1uI7eVn3vjcVAKxbjhd5J8+vAOByfKsp7kQosaIAsUYGPJFRQAPyAFc07DaX/SLaleTjO6N0XOOGuI3z+aRhV9nrxuNxp8Rz3yZpnUdvz7NF//ACrGu679uez4aNruzzb3lspdZIvCzheWR8fUCBxnPIA6Eg/LSO1H9J/0U7hd8f4l5QOglgjjiBA+4uN49Mitt2ZvjPawO6/xYY85896Ln9zXNPg/GUu5xkkQxMoH955olJ/SMfpU8TNkjh58Vp/D0j8+iL0iL1n3uyPLVAi7Y317cy2+lWcT9yxDSSv4cBiu7AK4BIOOWP2qw9pdSMFvNJxmONmGPUdB+pFUb4Ra2LS3uO4ha4u55VUDlURI04aV8YA3PIcDLHjjzFfhHDw3rbLmiNR7+332WZ/NGq07yu+iXl9Hcm21EWZYwd8DbmTwDvAgWQOOp8RGP5GrQ/Fu1aMWt/b+Ge2mVQQMkhssowOT4hjHmHYedb/Rbd0LzTP3s85DSyYxnbwFUeSKMhV9z1JrSal2gjutRtbKMh1glaWU5yDJEjlEHrtPiP3AHka4pasc2cvHrqtdzPyiOv19iL45ikRbvKyaRaOXN3eYa6lXGOq28Z5EMfoB/WbqxyfSsXtR23trDAmLO7DIjQAtt/mOSAB16nnHFZWpah3aO/BEasSM8naCT+1cl0LSGvIptQuiHMl5BAM9A0ksRkb2CFY19Nx9BU8Pizzcl82eekfevknLEYqxWveXadSsIbqIxTxiSNx0PUehB6gjyI5FcU7L6XdQ3d4dPkb8TpzOQvUXEKSlJEZR1PCNt88nGCFI7PHchVMjthUUs2fIAEn/ACqk/AhDJNqF9J4Qxxk9AZHaaT9B3f61q/4/54nJG/8AHp9VXJrqYb2btYmsW9tBBlRc5a8UHmKKLG+IkYPzHZFB803Himo2N3YAz6XM7xxgl7KZmkjZRye6LEshxngHH7H5dirWJfxF1FGIxfzNKq9MQ7j3ftkEyY8u8x5VgfFTtQbe3FvCT310CvHVYzwxGPNj4B7n0qM3Nz5efFME9I6fD4zJ6UVx7s6J2N7UQ6lbLcQZHO10PWNwASp9eCCD5git5VS+GHZY6dYpG/8AFlPeS+gdgAFH+6oVfuQT51ba+mZSlKUClKUClKUCsbUrwQwySsCVijZyB1IRSxx+lZNRljDAqwBDAgg9CCMEGgo/xJ1SdbRYUbupLhV71052I88EDKpPQkzjB/lV+hwRVfilq8tha262TdwokC+ALwiRsQoyCMcD9KvPb3Q3ngcwgs6wOqr6urxTxH14kgVf+IT5VRviBbDUNME0I3AKs6gdcbSHHuFZ+PUV43iUR/2ME3613MfDc+9owxuttd2bc2p1O0ltbxUS5hOCRyqybN0cqee11YHHozL5V8uxiMmnI0h3vumabect3iyuGy3JyAoX8q87P6ms5025VhuubV7Wcf7a0AkQn77e+Psw+1bDS7bc2pwr0/EHH2M9rE7f+5ifzry+dj9C18Efh3F4/af1n9F2K0Tq09+zm/ZGw761vr9wDILm0WM+jyXsUkmPyZB7Zq4/EUePTZDjcL+Ifbrn9wKrnw3uN9qLDBEraik0q9CsNvHGxJ/4saJ7tWZ8WZnnurOytzmXcGAHlJKwWPJ8sAMx9Ac16nLr6nNxY6+yJ+mtKaTrFMyt3auGRLO7cEbu4kJPoBG3StP8M1EWgXc3HhknkbP+zgCgD/0j9atenXC31rlhtMitHMh6xyAFJUI9Q2R7YPnVF7GabeJbzaVNbSqjXYklmIxGYVCbkQn6i5jUYHk7Zx0rJ4RyKYKZa5Z1NXWf/Py6W/s9atb2kSuRiGFOT5bIwTn9DVB+CqGSW8k9Viz/AI5JH/8AiatfxT11bWyeMMO9ugY1HmEI+Y3sF492FYXwc0p4IrrvV2uZYwR5jFukm0/cd7gjyOax4/NHBzZrf7zER+Uu72ickRHsWfV9OSdSkqB0OMqehwysM+v01or7UbSxXEskUWBxGo8XQDhFGfzxitX8Sr+d76zsbeeSLvyofuyVPzphGpJHPAVzjPvV00L4T6bbHe8TXT9S053jPrsACfmQT9608Dwu2bFW97arPXUff8LLczyTqsdVAt9R1HV/laZA0Fuch7hztyPPxDIHptTc33FW21+FSWlsptGV76KQSCV/CHKggxAc7UZWZfXJBJOBXS40CgBQAAMADgAfaqM+v381zcxQPZ234aTaI5Y5ZZHT+rKSJEAV+owD6ZzkD2ppxuJhncar7e89/exTe+S257tba3qXAdNm2RMiWGTiSIt1Vx6HPDDgjpVdsbN9LSeF7c32mXJzJGue+hbAG4Y5YAKvI5G0HgjLb3W9SSR1Gr2slnInEWoWpZ0H2YhdyqSfokDL1z61LQdaDT/hWuLW7buy6T27oyuqkA94isTG/iXjlTng8YryPJfhxOfjTF8ftj7+/fDX6tctfJkjUsSfs/c3tiy6VqcF1byqF+cGEqL5oZF5zjgh03YPXzrIuNE/o/TINMDKZr+Ru/ZM/RgNcMMjONgSEE4+pelazt1anTduo6e4t5u8VZYx/DuQ2Th06E9Tkc4yeCM1tNK1YahdSXLDZttoFijP1Kk0azu/szMEyOvc/kNkczFXh2z4a63+/ZTWk2yxW07ZU98kKMzkJHEpJ9Aqj/oKqnwv0p9U1GXUblflW7ju1PI7wDMa/wCBSHP95lPrWN8Tbx5JIdPthuknZSwHnubEan3PiPoFHka7N2U0JLG1ito+RGvib+dzy7H3Yk/5Vz4NxYpj9ae9u3y/tbzs0Wt5a9obalKV7TCUpSgUpSgUpSgUpSgVRNQ02SwlkeKGSezmcuyRrvktpHOXKoOWjYksVXJUk4BB4vdKo5HHpnpNLx0dVtNZ3D8/DWdLsblpLH8VcSlm2WgV444pXXYxw6BgcZXADEA4xjGM7s92e11Wm1ECGIz5eSCbfukVVyoEYGQQPCoLK3rXbpnRAXcogA5c4GB9yamjggFSCCMgjkEHoRVdOFiiJ827bjW7denuJvLlMMOqsDNYWOkn8SA34mNziQeTHIVj1PXODWw+H3w6ltrhr7UZlnumztC5KoWGC2SBlseEAABRkDPGMrU+xt5byPNol4sAkYs9rMN0BY8kpwSmepAH5gcVqZtM1+7xHd3ttZRMPGbcHeclRsyeQx3cAMM1Zh4uLDMzSutk2me52nmSXUGGmXK2sse38ZcZDQFiwSOFkY7GlPIB4Ph2567dXfanq4UbbmzQbCZC8axNbvtUpHNl2VHfeAoJOa33ZrToYEWGyCbI2G5pM92rMbUutzhtrXW7dsC8JwMDgH6rCfBjjAXb+JLFVBW1yNR8fM/J7r8qjJxMGS3mvSJn5EWmO0td2M+HcdxIl/fXp1Bjgqu0oqshPhdSc5Vsju8KAQcit1JaXVi85W1e8gmnkmDwle+QytuZXjcjdg5AKknAAxxVTha706VrjTxJJDLhprW4YiRSE3NJdSO5EczswCYGHUL1I5vfZ34iWN2dhl/DTg4aCf5UisOqjdwT9gc+oFM/FxZ8fp3jp9CLTE7hzzQopL3tGk5t7iOKBc/NjeMgJAVGQw4PeOT+VdwrwGvHYAZJAA6k8AVZix1x0ile0RpEzudnT2/auW/EHVhb3GL2OaPaC9rf2wVniQkbo54zwVDELzkMCv8AWyRY9Z+IVsjmCy/7fckHEUJBRcdWll+hFHmSePSsfRrGYEyXLb55WHeMoZeVYhUUH/ygB6/1iWY/VXdqxaNT2QqegfE0TSGH8NNdsoz3lrG7blHVmibDr9xlhnoTWdP28tosiKwv2cnlVtihJ++cf86t1/oZlQd1K1tMh3RzIMmOQhAdinhoSOqHg/YgEaeftHrVp4bjSY71R/bWsm3cPL5bBmz0z5eleVbwXizbepj4RPRZ6tnOe1VjqmpKLi5tzZ26OkcUcm5SXnlWIEggMTlgSxCgAeHqc2ntH2NuDGk0V87zWkRWMFEhUIADsjMIUr9IADFx5HqTX21rWdX1SJ7aLRPw0cuA0ty5GzBBDAEKQQQCCA2CAcV9bzsrqk8Rto9XicKoSdzDtbcR4kDqeeOvCtgjJ5rvPxc8eSnGmK1jvE/c7K2jrNmv+DOiR3UrapLcPNOpZCjoo7uQqBu3A4b5ZUDCrjLcV2Oq52E7JR6ZbdzG5kZm3yORjc5AXgc4ACgAZNWOvSiIiNQrKUpUhSlKBSlKBSlKBSlKDVdo+0NvYxd7cuVBYKqgFnkc9FRRyTWhu+3TrbyynTb+AiJmi76MBWcKSivsZimTgZYAc4zmsXtW0cesafNeFVgEMyRO/CJcsVPiY8AlAcZ6leOlXW3uo5lbu3SVclSVIZc45GRwfuKCi3fZrVYojcx6vLLdIu9oWRPw0hA3GNU4Kg/SGzn28rh2duI5LaJ4l2LLGsmzzTvh3m0jy+rpWwdQQQehGPTrXN+0OnW9lqOmf0bFHBPLNsliiAQSWu0mR5FXg7cZDHz9ccB0eaPcMbmX7jGR+vFaa77Oxy8TPNONwJV3KxnBH1JGFVsYyAwIyB6Ct0T5CvQKDTQ6eECJGi7VC7VYYRlU243SALjvBtOz2/TBWzJ24XdkKR3oOJQBb5a78H8UY8HsPysjRA9QDyCRgckYwT9xtGPasV7Ieaq+SMhguJCvd4d/B9Q28Y9B+QVk2GQMLv3Djvw2JcKmTfeD6lx8v8q02u9koLwL30JkYBu6km7yOQnEhIvXVAyoMDu+ecAc+d3exB6qH3AZ3qMTYA5m+VwVx4favjLp4YNlBJ3gIPeKPn4D4W4+Vwq58P8ArIczf4aBN/4G81C3VgwhVnkQLIvfFjOFiGyM92u1+d2fuM5DfDGF2JnmvrscrGtxJKo75BPkzYi3JEe7XbKDzu+4z0OXT92/K973m5T3iqPxHFxiG4+RxEu7wt58dc+P6yacG3ZHeb9ytvVMzr/2j5E3yf4K7/Cep++TvDSaJ2agtUMdrB3aM7g5U7pH3TAxzExZMGMBWJORjk8Z38Nr9j1xnHPX+GPB/C9KyUsxk55zwSQmWXL/ACz4PoG7j/8ASclYwPL7dB09Pag+UMQXHA6Y8vCOOBx9PH+vLy6ty/0yyRH1Xaf8nVl/PGayKj09v2oNTJorufm3t06HqimOEH/FEiyfo4rZ2tskSKkSKiKMBVAAA+wFfWlApSlApSlApSlApSlApSlApSlBVvigJf6KvO4GX7r0ydm4d4R99m85rZ9nNVtprWOW1eMQbBjGAIwB9JH9UjoR5YrbEVTn+F+lGUy/gkyW3FQ0gjJH+zDbMfbGPtQWXT7+G5j3wuksbErkcg44PuCOQehBBGQRVO7FQQJqepx2scexDCTIFBZJJFbvIg/UqNqnbnCkkegGV2g7P20spLpfWzkBTJaGYCVFGFD9yCOBhfEoI6AkAVvuzWh29nAIrSLukJ3HO7czHqzlvETwOvoBxjFBtAK9pSgUpSgiUB6gc9fvXjRg5yoO4YPA5HoanSgi0YOcgHIweOo54P6n9a9x517SgUpSgUpSgj09v2qVKj09v2oJUpSgUpSgUpSgUpSgUpSgUpSgVEnyFCfIV6BQYt3p0chBbeCPNJJIiR6EowJHXg+tZKIAAB0H3J/zPNSpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQKUpQKUpQKUpQKiT5ChPkK9AoAFe0pQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQKUpQKiT5ChPkK9AoAFe0pQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQR6e37VKlR6e37UEqUpQRj6fr+9SpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSg11KUoP/2Q==' /><br/>");
                    strBuild.Append("Process  = " + System.Reflection.Assembly.GetEntryAssembly().FullName + "<br/>");
                    strBuild.Append("#################### Exception begin ####################<br/>");
                }
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------<br/>");
                strBuild.Append("Message : " + inner.Message + "<br/>Stack Trace : " + inner.StackTrace + "<br/>");
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------<br/>");
                inner = inner.InnerException;
                if (inner == null)
                {
                    strBuild.Append("#################### Exception End ####################");
                    return false;
                }
                return true;
            });
            strBuild.Append("</div>");
            return strBuild.ToString();
        }
        public static string ProcessException(this Exception ex)
        {
            StringBuilder strBuild = new StringBuilder(5000);
            Exception inner = ex;
            Enumerable.Range(0, 30).All(x =>
            {
                if (x == 0) strBuild.Append("########## Exception begin  @ :" + DateTime.Now.ToString() + " ##########\n");
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------\n");
                strBuild.Append("Message : " + inner.Message + "\nStack Trace : " + inner.StackTrace + "\n");
                strBuild.Append("---------------------[" + x.ToString() + "]---------------------\n");
                inner = inner.InnerException;
                if (inner == null)
                {
                    strBuild.Append("########## Exception End @ :" + DateTime.Now.ToString() + " ##########\n\n");
                    return false;
                }
                return true;
            });
            return strBuild.ToString();
        }
    }
    public static class EmbeddedResourceUtils
    {
        //public static bool CopyFromResourceInSetupToDestination(this string resourceSourcefilename, string destinationstrFilePath)
        //{
        //    try
        //    {
        //        System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceSourcefilename).SaveStream(destinationstrFilePath);
        //    }
        //    catch (Exception ex)
        //    {
        //        ex.ProcessException();
        //        return false;
        //    }
        //    return true;
        //}
        //public static bool CopyFromResourceInSetupToDestinationAndDownload(this string resourceSourcefilename, ref string destinationstrFilePath, bool toPromptForSaveFileDialog = false, bool toOpen = false)
        //{
        //    try
        //    {
        //        if (toPromptForSaveFileDialog)
        //        {
        //            SaveFileDialog sfd = new SaveFileDialog();
        //            sfd.InitialDirectory = Path.GetDirectoryName(destinationstrFilePath);
        //            sfd.Filter = "Project files (*.xlsx)|*.xlsx";
        //            sfd.FileName = Path.GetFileName(destinationstrFilePath);
        //            if (sfd.ShowDialog() != DialogResult.OK) return false;
        //            destinationstrFilePath = sfd.FileName;
        //        }
        //        System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceSourcefilename).SaveStream(destinationstrFilePath);
        //        Helper.ShellExecute(IntPtr.Zero, "open", destinationstrFilePath, "", "", 1);
        //    }
        //    catch (Exception ex)
        //    {
        //        ex.ProcessException();
        //        return false;
        //    }
        //    return true;
        //}
        public static string CopyFromAppReferencesToDestinationAndDownload(this string resourceSourcefilename, ref string destinationstrFilePath, bool toOpen = false)
        {
            try
            {
                var ss = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceSourcefilename);
                ss.SaveStream(destinationstrFilePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ProcessException());
                return null;
            }
            return destinationstrFilePath;
        }
        private static bool SaveStream(this System.IO.Stream input, string destinationstrFilePath)
        {
            try
            {
                using (System.IO.FileStream fs = new System.IO.FileStream(destinationstrFilePath, System.IO.FileMode.Create))
                {
                    input.CopyTo(fs);
                    fs.Close();
                    fs.Dispose();
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ProcessException());
                return false;
            }
        }

        public static void CopyAllEmbeddedResources(this String[] appReferencesResources, bool alwaysCopy = false)
        {
            foreach (String resToBeCopied in appReferencesResources)
            {
                String res = resToBeCopied;
                if (File.Exists(res)) File.Delete(res);
            }
            System.Threading.Thread.Sleep(100);
            foreach (String resToBeCopied in appReferencesResources)
            {
                String res = resToBeCopied;
                if (!File.Exists(res)) (BasicAction.nsAppreferencesFolder + res).CopyFromAppReferencesToDestinationAndDownload(ref res);
            }
        }
    }
}
