using Confluent.Kafka;
using System.Reflection;
using TheWebSocketServer;
using Utils;
string fileName = "1.json";
(BasicAction.nsAppreferencesFolder + "1.json").CopyFromAppReferencesToDestinationAndDownload(ref fileName);

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//builder.Services.AddSingleton<ChatService>();
builder.Services.AddHostedService<MyTasks>();
//builder.Services.AddHostedService<KafkaConsumer>();

var app = builder.Build();
app.UseWebSockets();
// Configure the HTTP request pipeline.

var summaries = new[]
{
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
};

app.MapGet("/weatherforecast", () =>
{
    var forecast = Enumerable.Range(1, 5).Select(index =>
        new WeatherForecast
        (
            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            Random.Shared.Next(-20, 55),
            summaries[Random.Shared.Next(summaries.Length)]
        )).ToArray();
    return forecast;
});

//app.MapGet("/StartWebSocket", async (HttpContext context, ChatService chatService) =>
//{
//    if (context.WebSockets.IsWebSocketRequest)
//    {
//        var webSocket = await context.WebSockets.AcceptWebSocketAsync();
//        await chatService.HandleWebSocketConnection(webSocket);
//    }
//    else
//    {
//        context.Response.StatusCode = 400;
//        await context.Response.WriteAsync("Expected a WebSocket request");
//    }
//});

app.MapGet("/StartWebSocket", async (HttpContext context) =>
{
    if (context.WebSockets.IsWebSocketRequest)
    {
        var webSocket = await context.WebSockets.AcceptWebSocketAsync();
        await WebSocketService.HandleWebSocketConnection(webSocket);
    }
    else
    {
        context.Response.StatusCode = 400;
        await context.Response.WriteAsync("Expected a WebSocket request");
    }
    //WeatherForecast wf = new WeatherForecast(DateOnly.FromDateTime(DateTime.Now), 20, "Cool");//wf.TemperatureF
});

app.Run();

internal record WeatherForecast(DateOnly Date, int TemperatureC, string Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
