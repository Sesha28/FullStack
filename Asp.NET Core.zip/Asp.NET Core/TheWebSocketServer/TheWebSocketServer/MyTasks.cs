﻿using System.Xml;
using System.Xml.Serialization;

namespace TheWebSocketServer
{
    using Newtonsoft.Json;
    using Utils;

    //Let do some background Service
    public class MyTasks : IHostedService
    {
        static Book[] books = null;
        static string[] messages = new[] {   "Replica Server unavailable",   "Primary Server is online",   "New Order Received",   "Order Dispatched",   "Order Delivered",
                    "New User Registered",   "User Logged In",   "User Logged Out",   "New Product Added",   "Product Updated",   "Product Deleted",   "Server Maintenance Scheduled",
                    "Server Maintenance Completed",   "Database Backup Successful",   "Database Backup Failed",   "Payment Processed Successfully",   "Payment Failed",   "New Review Submitted",
                    "Review Approved",   "Review Rejected",   "Inventory Updated",   "Low Stock Alert",   "Out of Stock Alert",   "New Promotion Added",   "Promotion Updated",   "Promotion Expired",
                    "Customer Support Ticket Created",   "Customer Support Ticket Resolved",   "System Error Detected",   "System Error Resolved"  ,            "New Product Added", "Product Updated", "Product Deleted"
                };
        Task IHostedService.StartAsync(CancellationToken cancellationToken)
        {
            var tsk = new Task(async () =>
            {
                TimeSpan Interval = new TimeSpan(0, 0, 3);
                PeriodicTimer pTimer = new PeriodicTimer(Interval);
                while ((await pTimer.WaitForNextTickAsync(cancellationToken)))
                {
                    String message = "**** The time now is : " + DateTime.Now.ToString("HH:mm:ss") + " wait for " + Interval.Seconds + " seconds ****";
                    message = GetKafkaValuesAsJSON();
                    Console.WriteLine(new String(message.Take(100).ToArray()));
                    await WebSocketService.Boradcast(message);
                    Console.WriteLine("$$$$$$$$$$$$$$$$$ first 100 characters of what was sent $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
                }
            });
            tsk.Start();
            return tsk;
            //return Task.CompletedTask;
        }
        public string GetKafkaValuesAsJSON()
        {
            if (books == null)
            {
                string jText = File.ReadAllText(@"1.json");
                MyTasks.books = JsonConvert.DeserializeObject<Book[]>(jText);
            }
            Book book = MyTasks.books[BasicAction.rand.Next(MyTasks.books.Length - 1)];
            if (!book.id.Contains("_")) book.id += "_" + MyTasks.messages[BasicAction.rand.Next(MyTasks.messages.Length - 1)];
            string json = JsonConvert.SerializeObject(book, Formatting.Indented);
            return json;
        }

        public static T DeSerialize<T>(string xmlText) where T : class
        {
            T t = null;
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using (TextReader reader = new StringReader(xmlText))
            {
                t = serializer.Deserialize(reader) as T;
                return t;
            }
        }

        Task IHostedService.StopAsync(CancellationToken cancellationToken)
        {
            //throw new NotImplementedException();
            return Task.CompletedTask;
        }
    }
}
