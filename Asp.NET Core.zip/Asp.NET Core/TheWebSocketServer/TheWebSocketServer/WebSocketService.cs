﻿using System.Linq;
using System.Net.WebSockets;

namespace TheWebSocketServer
{
    public class WebSocketService
    {
        static Random rand = new();
        public static readonly List<WebSocket> sockets = new();

        public static async Task HandleWebSocketConnection(WebSocket socket)
        {
            WebSocketService.sockets.Add(socket);
            Console.WriteLine("New Connection Count : " + sockets.Count);
            var buffer = new byte[1024 * 2];
            while (socket.State == WebSocketState.Open)
            {
                //this will block until some web socket message is received
                WebSocketReceiveResult result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), default);
                //convert bytes to string
                String message = System.Text.Encoding.UTF8.GetString(buffer[..result.Count]) + "--" + rand.Next(10000);
                Console.WriteLine(message);
                if (result.MessageType == WebSocketMessageType.Close)
                {
                    await socket.CloseAsync(result.CloseStatus.Value, result.CloseStatusDescription, default);
                    break;
                }
                //await WebSocketService.Boradcast(message);
            }
            Console.WriteLine("Connection Closed");
            WebSocketService.sockets.Remove(socket);
        }
        public static async Task Boradcast(string message)
        {
            var buffer = new ArraySegment<byte>(System.Text.Encoding.UTF8.GetBytes(message));
            foreach (var socket in WebSocketService.sockets)
            {
                await socket.SendAsync(buffer, WebSocketMessageType.Text, true, default);
            }
        }
        public static async Task TelecastTo(string message, WebSocket socket)
        {
            var buffer = new ArraySegment<byte>(System.Text.Encoding.UTF8.GetBytes(message));
            await socket.SendAsync(buffer, WebSocketMessageType.Text, true, default);
        }
    }
}
