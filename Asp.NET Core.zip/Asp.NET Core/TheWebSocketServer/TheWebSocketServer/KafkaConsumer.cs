﻿
using Confluent.Kafka;

namespace TheWebSocketServer
{
    public class KafkaConsumer : IHostedService
    {
        ConsumerBuilder<string, string> consumerBuilder = null;
        public static bool isMonitoring = true;
        public Task StartAsync(CancellationToken cancellationToken)
        {
            //throw new NotImplementedException();
            //While receive from Kafka Q
            //await WebSocketService.Boradcast(message);

            consumerBuilder = new(new ConsumerConfig
            {
                BootstrapServers = "localhost:9092",
                GroupId = "Kafka:Consumer:KafkaGroupId",
                AutoOffsetReset = AutoOffsetReset.Earliest
            });
            var consumerConfig = consumerBuilder.Build();
            consumerConfig.Subscribe("Kafka:Consumer:KafkaTopic");
            var tsk = new Task(() =>
            {
                while (isMonitoring)
                {
                    var consumeResult = consumerConfig.Consume(cancellationToken);
                    Console.WriteLine($"Consumed message '{consumeResult.Message.Value}' at: '{consumeResult.TopicPartitionOffset}'.");
                    WebSocketService.Boradcast(consumeResult.Message.Value).RunSynchronously();
                    Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
                }
            });tsk.Start();
            return tsk;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }
}
