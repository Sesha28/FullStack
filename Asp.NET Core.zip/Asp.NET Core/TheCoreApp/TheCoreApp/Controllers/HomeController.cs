﻿using Microsoft.AspNetCore.Mvc;
using Models;
using System.Diagnostics;
using TheCoreApp.Models;

namespace TheCoreApp.Controllers
{
    using Newtonsoft.Json;
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            ViewData["Shola"] = "Amazing Captian Nemo";
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Search()
        {
            return View();
        }
        /// <summary>
        /// url : ~/Home/GetTime
        /// </summary>
        /// <returns></returns>
        public String GetTime()
        {
            string? txt = Request.Query["txt"];
            if(String.IsNullOrEmpty(txt)) txt = "";
            txt += " from  TheCoreApp " + DateTime.Now.ToString("yyyy:MM:dd- hh:mm:ss ");
            return txt;
        }
       

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        /// <summary>
        /// url : ~/Home/GetStudents
        /// </summary>
        /// <returns></returns>
        public string GetStudents()
        {
            var students = new List<Student>();
            students.Add(new Student { Age = 28, Name = "Tiru" });
            students.Add(new Student { Age = 25, Name = "Pandav" });
            students.Add(new Student { Age = 26, Name = "Mahadev" });
            students.Add(new Student { Age = 27, Name = "Panchali" });
            students.Add(new Student { Age = 33, Name = "Vasudev" });
            students.Add(new Student { Age = 3, Name = "Chandra" });
            students.Add(new Student { Age = 1, Name = "Janaki" });
            students.Add(new Student { Age = 12, Name = "Chandra" });
            students.Add(new Student { Age = 21, Name = "Basava" });
            students.Add(new Student { Age = 23, Name = "Anjaneya" });

            return JsonConvert.SerializeObject(students);
        }
    }
}
