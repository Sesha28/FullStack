﻿namespace Models
{
    public class Student
    {
        public int Age { get; set; }
        public string Name { get; set; }
    }
}
