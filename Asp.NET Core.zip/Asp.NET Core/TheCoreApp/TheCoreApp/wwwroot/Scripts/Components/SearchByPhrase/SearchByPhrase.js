﻿var SearchByPhrase = {
    no_results_msg: `<div  class="row border border-1 rounded-10" >
                        <div class="col bg-dark rounded-10 ps-5 pt-5" style="padding-bottom:50px;">
                            <h1 class="caption" style="font-size:70px;">Oops !!! </h1>
                            <p class="fw-bolder"> Sorry ! there is no such thing in our DB</p>
                            <p> 
                                Either these mails ids are not registerd with us or
                                no keyword/s match the stuff we have in our DB.
                                Please note we implement full text-search with PostGress DB.
                                Better Check this with <b class='glow'>Cariappa</b><br/>
                                <span id='special_msg'></span>
                            </p>
                            <p>
                                <a onclick="SearchByPhrase.CallForHelp(event,$('#email').val(),$('#phrase').val())" >
                                    <i class="bi bi-mailbox text-blazing me-2"></i>
                                    <font class="fs-small text-warning">Click here to get in touch <b class='glow'>Cariappa</b></font>
                                </a>
                            </p>
                        </div>
                        <div id='mood' class="col bg-warning rounded-right-10 just-blur" 
                             style="background-image: url(_IMG_); background-size: cover;">
                        </div>
                    </div> `,
    //templ_html: `<div>
    //    <h3>The questions : </h3>
    //    {{#each questions as |q|}}
    //    <div id="id_{{q.id}}">
    //        {{@index}}. {{q.question}}
    //        <a target="_blank" href="/VNVOverflow/Home/AnswerToAQuestion?qid={{q.id}}#answer"
    //           class="p-2 btn  btn-sm btn-primary rounded-circle float-end"><i class="bi bi-train-freight-front-fill pe-none"></i></a>
    //    </div>
    //    <hr />
    //    {{/each}}
    //</div>`,
    total_count: 0,
    total_pages: 0,
    total_batches: 0,
    batch_size: 10,
    templ_html: null,
    page: '<span page="_INDEX_" onclick="SearchByPhrase.GetNextBatch(event, _LIMIT_,_OFFSET_)" style="cursor:pointer;"  class="badge bg-primary cursor-pointer m-1" limit=_LIMIT_ offset=_OFFSET_>_INDEX_</span>',
    batch: '<span batch="_INDEX_"onclick="SearchByPhrase.GetNextBatchOfPages(event, _INDEX_)" style="cursor:pointer;"  class="badge bg-primary cursor-pointer m-1 rounded-circle text-black p-2" >_INDEX_</span>',
    max_records_per_page: 50,
    compiled_html: '',
    ask_cariappa: "mailto:cariappa.bollianda-1@gmail.com?subject=VnVOverflow&cc=shanthi.kalarikkal-1@gmail.com&body=Hi Cariappa Sir,%0AI deeply regret to inform that this query of mine %0A_QUERY_%0A%0AThanks and Regards",
    start_action: function (data, tag) {
        new TemplateRenderer(data, tag, "~/Scripts/Components/SearchByPhrase/SearchByPhrase.html", null, false, false).start_action().
            then(jD => $("div[the_results]").addClass("d-none"));
    },
    CallForHelp: function (e, mail, tags) {
        let href = $(e.target).closest("a");
        let final_href = SearchByPhrase.ask_cariappa.replace(/_QUERY_/g, "%0AMails : " + mail + "%0AKeyword/s : " + tags + `%0A%0AYielded no results.%0A%0AI was also told that Either these mails ids are not registerd with us or no keyword/s match the stuff we have in our DB. Please note we implement full text-search with PostGress DB. %0ABetter Check this with Cariappa`);
        href.attr({ "href": final_href });
    },
    GetNextBatch: function (e, limit, offset) {
        $("span[page]").removeClass("bg-secondary");
        $(e.target).addClass("bg-secondary");
        let phrase = $('#phrase_only').val();
        let mails = $("#email_only").val();        
        $.ajax({
            url: config.contextPath + "Home/GetAllQuestionsBy",
            data: { "phrase": phrase, "offset": offset, "limit": limit, "mail": mails }
        }).then(jData => {
            let jd = JSON.parse(jData);
            if (!jd || jd.length <= 0) {
                $("#search_by_phrase_results").html(SearchByPhrase.no_results_msg);
                return;
            }
            //SearchByPhrase.templ_html = $("#search_by_phrase_template").text().replace(/__BB__/g, '{{').replace(/__EB__/g, '}}');
            if (!SearchByPhrase.templ_html) SearchByPhrase.templ_html = $("#search_by_phrase_template").text().replace(/\[\[/g, '{{').replace(/\]\]/g, '}}');
            //SearchByPhrase.compiled_html = Handlebars.compile(SearchByPhrase.templ_html)({"mails":mails, questions: jd });
            SearchByPhrase.compiled_html = Handlebars.compile(SearchByPhrase.templ_html)({ questions: jd });
            $("#search_by_phrase_results").html(SearchByPhrase.compiled_html);
            $("div[phrase_pager]").removeClass("d-none")
        });
    },
    GetQuestions: async function (e, mails, phrase) {
        $("#batch_paging").html(""); $("#total_pages").html(""); $("div[the_results]").addClass("d-none");
        if (!mails && !phrase) {
            $("div[the_results]").removeClass("d-none");
            $("#search_by_phrase_results").html(SearchByPhrase.no_results_msg);
            $("#mood").css({ "background-image": "url(/VnVOverflow/wwwroot/img/z.jpg)" });
            $("#special_msg").html("<span class='fs-very-small'>We even searched with Lanterns, but still we could not find anything</span>");
            return;
        } 
        await SearchByPhrase.GetTotalQuestionCount(mails, phrase);
        if (!SearchByPhrase.total_count) {
            $("div[the_results]").removeClass("d-none");
            $("#search_by_phrase_results").html(SearchByPhrase.no_results_msg);
            $("#mood").css({ "background-image": "url(/VnVOverflow/wwwroot/img/Sad.jpg)" });
            $("#special_msg").html();
            return;
        }
        SearchByPhrase.DoThePagesThing();
        SearchByPhrase.DoTheBatchesOfPagesThing(SearchByPhrase.total_pages);
    },
    GetTotalQuestionCount: async function (mails, phrase) {
        if (mails) mails = mails.replace(/@gmail.com/g, '');
        SearchByPhrase.total_count = await $.ajax({ url: config.contextPath + "Home/GetAllQuestionsbyMailAndPhraseCount", data: { "mail": mails, "phrase": phrase } });
        SearchByPhrase.total_count = parseInt(SearchByPhrase.total_count);
    },
    DoThePagesThing: function () {
        SearchByPhrase.total_pages = Math.ceil(Math.round(SearchByPhrase.total_count / SearchByPhrase.max_records_per_page));
        $("#total_pages").html("Pages : " + SearchByPhrase.total_pages + " Total Records : " + SearchByPhrase.total_count);
        let badges = '';
        for (let i = 0; i < SearchByPhrase.total_pages; ++i) {
            if (i === SearchByPhrase.total_pages - 1) {
                let limit = SearchByPhrase.total_count - SearchByPhrase.max_records_per_page * (SearchByPhrase.total_pages - 1);
                badges += SearchByPhrase.page.replace(/_LIMIT_/g, limit).replace(/_OFFSET_/g, i * SearchByPhrase.max_records_per_page).replace(/_INDEX_/g, i)
            }
            else badges += SearchByPhrase.page.replace(/_LIMIT_/g, SearchByPhrase.max_records_per_page).replace(/_OFFSET_/g, i * SearchByPhrase.max_records_per_page).replace(/_INDEX_/g, i)
        }
        if (SearchByPhrase.total_pages) {
            $("#batches").html(badges);
            $("div[the_results]").removeClass("d-none");
        }
    },
    DoTheBatchesOfPagesThing: function (totalpages) {
        if (!totalpages) return;
        SearchByPhrase.total_batches = Math.ceil(Math.round(totalpages / SearchByPhrase.batch_size));
        let BatchesOfPages = '';
        for (let i = 0; i < SearchByPhrase.total_batches; ++i)  BatchesOfPages += SearchByPhrase.batch.replace(/_INDEX_/g, i);
        $("#batch_paging").html(BatchesOfPages);
        //$("span[batch]").addClass("rotateZ");
        SearchByPhrase.GetNextBatchOfPages({ target: $("span[batch='0']")[0] }, 0);//Actually u get the first batch of pages
    },
    GetNextBatchOfPages: function (e, index) {
        $("span[batch]").removeClass("bg-secondary").addClass("bg-primary");
        $("span[page]").addClass("d-none");
        $(e.target).addClass("bg-secondary");
        let start = SearchByPhrase.batch_size * index;
        for (let i = start; i <= start + SearchByPhrase.batch_size; ++i) $("span[page='" + i + "']").removeClass("d-none");
        let jEle = $('span[page=' + start + ']');
        SearchByPhrase.GetNextBatch({ target: jEle[0] }, parseInt(jEle.attr("limit")), parseInt(jEle.attr("offset")));
    }
}