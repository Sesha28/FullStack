﻿var Intro = {
    start_action: function (data, tag,) {
        new TemplateRenderer(data, tag, "~/Scripts/Components/Intro/Intro.html", null, false, false).start_action().
            then(jData => {
                setTimeout(() => {
                    //alert("labamba");
                    $("#intro_img").addClass("blurring");
                }, 5000)
            });
    },
}