﻿var Footer = {
    start_action: function () {
        new TemplateRenderer({ obj: "TheFooter" }, "Footer", "~/Scripts/Components/Footer/Footer.html").start_action();
    }
}