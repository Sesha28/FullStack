var AskAQuestion = {
    intr: null,
    start_action: function (data, tag) {
        new TemplateRenderer(data, tag, "~/Scripts/Components/AskAQuestion/AskAQuestion.html", null, false).start_action();
    },
    post_click_button: async function (e) {
        let user_details = await $.ajax({ url: config.contextPath + "Home/GetUserDetails" });
        if (!user_details) {
            LogIn.ShowLoginDialog();
            return;
        }
        //e.preventDefault();
        let question = $("#question1").val();
        if (!question) return;
        question = question.ReplaceDanger();
        let category = $("#category :selected").val();
        if (!question || !category) {
            alert("All field are mandatory");
            return;
        }
        var fd = new FormData();
        var files = $('#askFile')[0].files[0];
        fd.append('my_file', files);
        fd.append('question', question);
        fd.append('category', category);
        $.ajax({
            url: config.contextPath + "Home/SubmitQuestion",
            type: "POST",
            contentType: 'multipart/form-data',
            data: fd,
            contentType: false,
            processData: false            
        }).then(jData => {
            Alertify.ShowAlertDialog({
                "title": "This is a serious matter",
                "body": jData,
                "buttons": ["Ok Now what", "Let me wait"],
                "foot_note": "Welcome to V<sub>&</sub>V Overflow"
            });
        });
    },
};