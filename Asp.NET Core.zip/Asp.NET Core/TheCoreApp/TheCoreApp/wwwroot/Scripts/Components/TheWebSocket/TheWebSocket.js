﻿var TheWebSocket = {
    ws: null,
    start_action: function (tag, data) {
        return new TemplateRenderer(data, tag, "~/Scripts/Components/TheWebSocket/TheWebSocket.html", null, false).start_action().
            then(jData => {
                //TheWebSocket.doTheWebSocketThing();
                TheWebSocket.doTheWebSocketThingMVC();
                $(document).keyup(function (event) {
                    //get enter key key up
                    if (event.keyCode === 13) TheWebSocket.wsSendMVC();
                });
                return "Websocket is ready to be used";
            });
    },
    doTheWebSocketThing: function () {
        // This is the function that will be called when the WebSocket is opened
        TheWebSocket.ws = new WebSocket("ws://localhost:5137/StartWebSocket");
        TheWebSocket.ws.onopen = function () {
            $("#status").val("WebSocket is open now. about to send \"Hello Server \"");
            TheWebSocket.ws.send("Hello, Server");
        };
        TheWebSocket.ws.onmessage = function (evt) {
            TheWebSocket.wsReceive(evt);
            //console.log("Received: " + evt.data);
        };
        TheWebSocket.ws.onclose = function () {
            //console.log("WebSocket is closed now.");
            $("#status").val("Connection Closed");
        };
    },
    wsSend: function (e) {
        let msg = $("#ws_text").val();
        if (!msg) {
            $("#status").val("Nothing to Send so not sending, happy ?");
            return;
        }
        TheWebSocket.ws.send(msg);
        $("#status").val("Sent: " + msg);
    },
    wsReceive: function (evt) {
        let data = JSON.parse(evt.data);        
        $("#the_id").html(`Id : ${ data.id } <br/> Title : ${ data.title }`);
            //$("#the_id").text("Id : " + data.id + " + , Title : "+ "+ data.title");
        let thresh = 50;
        //$("#status").val(JSON.stringify(data));
        let clr = "rgb(_R_, _G_, _B_)";
        let r = 125 + Math.random() * 125; let g = r; let b = r;
        //let rContrast = 255 - r; let gContrast = 255 - g; let bContrast = 255 - b;
        let rContrast = 0; let gContrast = 0; let bContrast = 0;
        let bkColor = clr.replace("_R_", r).replace("_G_", g).replace("_B_", b);
        //if (Math.abs(r - rContrast) < thresh) rContrast = 0; if (Math.abs(g - gContrast) < thresh) gContrast = 0; if (Math.abs(b - bContrast) < thresh) bContrast = 0;

        let txtColor = clr.replace("_R_", rContrast).replace("_G_", gContrast).replace("_B_", bContrast);
        $("#lgTxt").val(evt.data).css({ "background-color": bkColor, "color": txtColor });

        r = 125 + Math.random() * 125; g = b = r;
        rContrast = 0; gContrast = 0; bContrast = 0;
        //if (Math.abs(r - rContrast) < thresh) rContrast = 0; if (Math.abs(g - gContrast) < thresh) gContrast = 0;if (Math.abs(b - bContrast) < thresh) bContrast = 0;
        txtColor = clr.replace("_R_", rContrast).replace("_G_", gContrast).replace("_B_", bContrast);
        bkColor = clr.replace("_R_", r).replace("_G_", g).replace("_B_", b);
        $("#status").val(data.History.Evt.desc).css({ "background-color": bkColor, "color": txtColor });
    },
    doTheWebSocketThingMVC: function () {
        // This is the function that will be called when the WebSocket is opened
        TheWebSocket.ws = new WebSocket("ws://localhost:5137/StartWebSocket");
        TheWebSocket.ws.onopen = function () {
            $("#status").val("WebSocket is open now. about to send \"Hello Server \"");
            TheWebSocket.wsSendMVC("Hello, Server");
        };
        TheWebSocket.ws.onmessage = function (evt) {
            TheWebSocket.wsReceive(evt);
            //console.log("Received: " + evt.data);
        };
        TheWebSocket.ws.onclose = function () {
            //console.log("WebSocket is closed now.");
            $("#status").val("Connection Closed");
        };
    },
    wsSendMVC: function (e) {
        let msg = $("#ws_text").val();
        if (!msg) {
            $("#status").val("Nothing to Send so not sending, happy ?");
            return;
        }
        let WebSocketRequest = {};
        WebSocketRequest.url = "Home/Index";
        WebSocketRequest.data = msg;
        TheWebSocket.ws.send(JSON.stringify(WebSocketRequest));
        $("#status").val("Sent: " + msg);
    },
    Start: function (e) {
        TheWebSocket.doTheWebSocketThingMVC();
    }
}