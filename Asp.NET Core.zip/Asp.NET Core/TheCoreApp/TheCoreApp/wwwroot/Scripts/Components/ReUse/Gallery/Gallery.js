﻿var Gallery = {
    start_action: function (tag, data) {
        new TemplateRenderer(data, tag, "~/Scripts/Components/ReUse/Gallery/Gallery.html", null, false).start_action()
    }
}