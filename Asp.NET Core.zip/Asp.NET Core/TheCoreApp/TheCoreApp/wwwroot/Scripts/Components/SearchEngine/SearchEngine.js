﻿var SearchEngine = {
    no_results_msg: `<div  class="row border border-1 rounded-10" >
                        <div class="col bg-dark rounded-10 ps-5 pt-5" style="padding-bottom:50px;">
                            <h1 class="caption" style="font-size:70px;">Oops !!! </h1>
                            <p class="fw-bolder"> Sorry ! there is no such thing in our DB</p>
                            <p> 
                                Either these mails ids are not registerd with us or
                                no keyword/s match the stuff we have in our DB.
                                Please note we implement full text-search with PostGress DB.
                                Better Check this with <b class='glow'>Cariappa</b>
                            </p>
                            <p>
                                <a onclick="SearchEngine.CallForHelp(event,$('#email').val(),$('#phrase').val())" >
                                    <i class="bi bi-mailbox text-blazing me-2"></i>
                                    <font class="fs-small text-warning">Click here to get in touch <b class='glow'>Cariappa</b></font>
                                </a>
                            </p>
                        </div>
                        <div class="col bg-warning rounded-right-10 just-blur" 
                             style="background-image: url(/VnVOverflow/wwwroot/img/Sad.jpg); background-size: cover;">
                        </div>
                    </div> `,
    templ_html: `<div>
        <h3>The questions : </h3>
        {{#each questions as |q|}}
        <div id="id_{{q.id}}">
            {{@index}}. {{q.question}}
            <a target="_blank" href="/VNVOverflow/Home/AnswerToAQuestion?qid={{q.id}}#answer" 
               class="p-2 btn  btn-sm btn-primary rounded-circle float-end"><i class="bi bi-train-freight-front-fill pe-none"></i></a>
        </div>
        <hr />
        {{/each}}
    </div>`,
    compiled_html: '',
    ask_cariappa:"mailto:cariappa.bollianda-1@alstomgroup.com?subject=VnVOverflow&cc=shanthi.kalarikkal-1@alstomgroup.com&body=Hi Cariappa Sir,%0AI deeply regret to inform that this query of mine %0A_QUERY_%0A%0AThanks and Regards",
    start_action: function (data, tag) {
        new TemplateRenderer(data, tag, "~/Scripts/Components/SearchEngine/SearchEngine.html", null, false, false).start_action();
    },
    CallForHelp: function (e, mail, tags) {
        let href = $(e.target).closest("a"); 
        let final_href = SearchEngine.ask_cariappa.replace(/_QUERY_/g, "%0AMails : " + mail + "%0AKeyword/s : " + tags +`%0A%0AYielded no results.%0A%0AI was also told that Either these mails ids are not registerd with us or no keyword/s match the stuff we have in our DB. Please note we implement full text-search with PostGress DB. %0ABetter Check this with Cariappa`);
        href.attr({ "href": final_href });
    },
    GetQuestions: function (e, mails, phrase) {
        if (mails) mails = mails.replace(/@alstomgroup.com/g, '');
        $.ajax({ url: config.contextPath + "Home/GetAllQuestionsBy", data: { "mail": mails, "phrase": phrase } }).
            then(jData => {
                let jd = JSON.parse(jData);
                if (!jd || jd.length <= 0) {                    
                    $("#mail_search_results").html(SearchEngine.no_results_msg);
                    return;
                }
                //SearchEngine.templ_html = $("#search_template").text().replace(/__BB__/g, '{{').replace(/__EB__/g, '}}');
                SearchEngine.templ_html = $("#search_template").text().replace(/\[\[/g, '{{').replace(/\]\]/g, '}}');
                //SearchEngine.compiled_html = Handlebars.compile(SearchEngine.templ_html)({"mails":mails, questions: jd });
                SearchEngine.compiled_html = Handlebars.compile(SearchEngine.templ_html)({ "mail": mails, questions: jd });
                $("#mail_search_results").html(SearchEngine.compiled_html);
            });
    }
}