﻿var BasicInfo = {
    start_action: function (tag, data) {
        $.ajax({ url: "/Home/GetStudents" }).then(jData => {
            let students = { people: JSON.parse(jData) }
            data = students;
            return new TemplateRenderer(data, tag, "~/Scripts/Components/BasicInfo/BasicInfo.html", null, false, true).start_action().
                //then(jData => { alert(jData + " Dun dana done") }).
                then(jData => jData)
                .catch((a, b, c) => alert("A Major Catastrophe : " + c));
        });
    }
}
