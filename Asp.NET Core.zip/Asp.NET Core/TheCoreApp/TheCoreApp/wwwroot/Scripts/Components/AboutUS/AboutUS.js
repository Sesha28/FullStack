﻿var AboutUS = {
    start_action: function () {
        new TemplateRenderer({ obj: "TheAboutUS" }, "AboutUS", "~/Scripts/Components/AboutUS/AboutUS.html").start_action();
    }
}