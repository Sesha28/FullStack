var AllQuestions = {
    End_Batch_AllQuestions: true,
    Start_Batch_AllQuestions: true,
    Current_Page_AllQuestions: true,
    Records_Per_Page_AllQuestions: true,
    Total_Records_AllQuestions: true,
    Total_Pages_AllQuestions: true,
    Go_to_Page_AllQuestions: true,
    Page_Bar_AllQuestions: true,
    isEditable: false,
    containerJID: '#pager_AllQuestions',
    totalRecordsJID: '#totalRecords_AllQuestions',
    totalPagesJID: '#totalPages_AllQuestions',
    RecordsPerPageJID: '#RecordsPerPage_AllQuestions',
    CurrentPageJID: '#CurrentPage_AllQuestions',
    GoToPageJID: '#GoToPage_AllQuestions',
    itemsJID: '#items_AllQuestions',
    TableContJID: '#TableCont_AllQuestions',
    pitem: 'pitem_AllQuestions',
    actualobjectName: 'AllQuestions.theUsageTable',
    headerMapping: {
        "id": '<div class="rotateXYZ d-inline-block"><i class="fs-3 bi bi-fuel-pump-fill pe-none"></i></div>',
        "question": '<div class="rotateZ d-inline-block"><i class="fs-3 bi bi-patch-question-fill pe-none"></i></div>',
        "mail": '<i class="fs-3 bi bi-mailbox pe-none"></i>',
        "insert_time_stamp": '<div class="shake d-inline-block"><i class="fs-3 bi bi-alarm-fill pe-none"></i></div>'
    },
    deleteCallback: (row, jData) => {
        AllQuestions.currentRow = row; //store this row object for future use
        alert('About to delete\n' + JSON.stringify(jData, null, ' '));
        AllQuestions.theUsageTable.remove_row(AllQuestions.currentRow);
        //make Ajax call and get the jData deleted at the Back end/ DB
        //$.ajax({ url: "back end url to delete jData from DB", data: { toDel: JSON.stringify(jData) } }).done((jRespData) => {
        //            AllQuestions.theUsageTable.remove_row(AllQuestions.currentRow);
        //        }).catch(jCatch => jCatch);
    },
    editCallback: (row, jData) => {
        AllQuestions.currentObject_1 = jData;
        AllQuestions.currentRow = row;//store this row object for future use
        for (let k in AllQuestions.headerMapping) $("#" + k + '_AllQuestions').val(jData[k]);
        if (!AllQuestions.myModal) AllQuestions.myModal = new bootstrap.Modal(document.getElementById('pager_edit_AllQuestions'))
        AllQuestions.myModal.toggle();
        //After jData gets Edited you can do the following
        //AllQuestions.theUsageTable.edit_row(this.currentRow, this.currentObject_1);
    },
    save_click: function (e) {
        var theObj = {};
        for (let k in AllQuestions.headerMapping) theObj[k] = $("#" + k + '_AllQuestions').val();
        alert("Send this object to back end for editing\nUpon success make the following call :\nAllQuestions.theUsageTable.edit_row(AllQuestions.currentRow, theObj)" + JSON.stringify(theObj, null, ' '));
        AllQuestions.theUsageTable.edit_row(AllQuestions.currentRow, theObj);
        //$.ajax({ url: config.contextPath + "Home/editobject?theObj="_OBJ_ }).done((jRespData) => {
        //    //jData.Name = "Labamba_" + jData.Name.split('_')[1] ;
        //    TheTopTable.theTable.edit_row(this.currentRow, this.currentObject_1);
        //    //this.myModal.toggle();
        //});
    },
    sortCallBack: (e, byWhat, direction) => {
        alert("In Sort Callback \nbyWhat = " + byWhat + "\ndir = " + direction + "\nOffset = " + AllQuestions.theUsageTable.offset + "\nLimit = " + AllQuestions.theUsageTable.itemsPerPage);
        AllQuestions.theUsageTable.start_action();
    },
    getTable: (offset, limit) => {
        //make an AJAX call and return the ajax response as a promise
        var url = AllQuestions.getPageDataURL;
        url = url.replace('_OFFSET_', offset).replace('_LIMIT_', limit);
        return $.ajax({ url: url, context: this });
    },
    GetRecordCount: () => $.ajax({ url: AllQuestions.TotRecURL, context: this }).then(jData => parseInt(jData)),
    CellRenderCallBack: (row, col, rowData) => {
        switch (col) {
            case "id": {
                let html_template = '<a target="_blank" href="/VnVOverflow/Home/AnswerToAQuestion?qid=_ID_#answer" class="btn btn-sm btn-warning">_ID_ _ICON_</a>'
                let html = html_template.replace(/_ID_/g, rowData[col]).replace(/_ICON_/g, ' <i class="bi bi-mouse2"></i>');
                return html;
            }
            case "question": return rowData[col].ReplaceDanger();
            case "mail": {
                if (rowData[col].indexOf("sai") != -1) return "<span class='badge bg-primary rounded-pill p-2'><i class='bi bi-mailbox2-flag'></i> " + rowData[col] + "</span>" + '</i>'
                else return false;
            }
            case "insert_time_stamp": return new Date(rowData[col].replace(' ', 'T')).toString().split('GMT')[0];
            default: return false;
        }
    },
    start_action: function (data, tag) {
        new TemplateRenderer(data, tag, "~/Scripts/Components/AllQuestions/AllQuestions.html", null, false, false).start_action();
            //then(jData => {
            //    if (!AllQuestions.theUsageTable) AllQuestions.theUsageTable = new Pest(AllQuestions, "AllQuestions.theUsageTable");
            //    AllQuestions.theUsageTable.start_action().
            //        then(jData => {
            //            setTimeout(() => {
            //                //$("#head_AllQuestions tr").append('<td><i class="bi bi-arrow-up-circle-fill"></i></td>');
            //                ////$("#TableCont_AllQuestions tr").append("<td><a target='_blank' href='/VnVOverflow/Home/AnswerToAQuestion?qid=1' class='btn btn-sm btn-primary'>View</a></td>");
            //                //$.each($("#TableCont_AllQuestions tr"), (i, val) => {
            //                //    let theRow = $(val);
            //                //    let jRowData = JSON.parse(theRow.attr("tr_dat"));
            //                //    theRow.append("<td><a target='_blank' href='/VnVOverflow/Home/AnswerToAQuestion?qid=" + jRowData.id + "' class='btn btn-sm btn-primary'>View</a></td>");
            //                //    let firstTD = theRow.find("td:first-child");
            //                //    let txt = firstTD.text();
            //                //    firstTD.html("<a target='_blank' href='/VnVOverflow/Home/AnswerToAQuestion?qid=" + jRowData.id + "' class='btn btn-sm btn-primary'>" + txt + "</a>")
            //                //})

            //            }, 1000);
            //        });
            //    theApp.AOSInitialize();
            //});
    },
    data: null, tag: null,
    theUsageTable: null,
    TotRecURL: "/VnVOverflow/" + 'Home/GetAllQuestionCount',
    getPageDataURL: "/VnVOverflow/" + "Home/GetNextSetFromAllQuestions?offset=_OFFSET_&limit=_LIMIT_&orderby=id",
}
//*****************AllQuestions.start_action(); *********************