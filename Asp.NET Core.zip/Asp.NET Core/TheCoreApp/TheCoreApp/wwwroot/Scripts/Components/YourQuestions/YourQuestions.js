﻿var YourQuestionsTable = {
    End_Batch_EditQuestionTable: true,
    Start_Batch_EditQuestionTable: true,
    Current_Page_EditQuestionTable: true,
    Records_Per_Page_EditQuestionTable: true,
    Total_Records_EditQuestionTable: true,
    Total_Pages_EditQuestionTable: true,
    Go_to_Page_EditQuestionTable: true,
    Page_Bar_EditQuestionTable: true,
    isEditable: false,
    containerJID: '#pager_EditQuestionTable',
    totalRecordsJID: '#totalRecords_EditQuestionTable',
    totalPagesJID: '#totalPages_EditQuestionTable',
    RecordsPerPageJID: '#RecordsPerPage_EditQuestionTable',
    CurrentPageJID: '#CurrentPage_EditQuestionTable',
    GoToPageJID: '#GoToPage_EditQuestionTable',
    itemsJID: '#items_EditQuestionTable',
    TableContJID: '#TableCont_EditQuestionTable',
    pitem: 'pitem_EditQuestionTable',
    actualobjectName: 'YourQuestionsTable.theUsageTable',
    headerMapping: {
        "sno": '<span class="d-inline-block rotateXYZ"> <i class="fs-3 bi bi-fuel-pump-fill pe-none"></i></span>',
        "question": '<span class="d-inline-block rotateZ">Question</span>',
        "Urvashi": "<span class='d-inline-block'>Column Added @<br/>Render Phase</span>",
        "insert_time_stamp": '<span class="d-inline-block shake"><i class="fs-3 bi bi-alarm-fill pe-none "></i></span>'
    },
    deleteCallback: (row, jData) => {
        YourQuestionsTable.currentRow = row; //store this row object for future use
        alert('About to delete\n' + JSON.stringify(jData, null, ' '));
        YourQuestionsTable.theUsageTable.remove_row(YourQuestionsTable.currentRow);
        //make Ajax call and get the jData deleted at the Back end/ DB
        //$.ajax({ url: "back end url to delete jData from DB", data: { toDel: JSON.stringify(jData) } }).done((jRespData) => {
        //            YourQuestionsTable.theUsageTable.remove_row(YourQuestionsTable.currentRow);
        //        }).catch(jCatch => jCatch);
    },
    editCallback: (row, jData) => {
        YourQuestionsTable.currentObject_1 = jData;
        YourQuestionsTable.currentRow = row;//store this row object for future use
        for (let k in YourQuestionsTable.headerMapping) $("#" + k + '_EditQuestionTable').val(jData[k]);
        if (!YourQuestionsTable.myModal) YourQuestionsTable.myModal = new bootstrap.Modal(document.getElementById('pager_edit_EditQuestionTable'))
        YourQuestionsTable.myModal.toggle();
        //After jData gets Edited you can do the following
        //YourQuestionsTable.theUsageTable.edit_row(this.currentRow, this.currentObject_1);
    },
    save_click: function (e) {
        var theObj = {};
        for (let k in YourQuestionsTable.headerMapping) theObj[k] = $("#" + k + '_EditQuestionTable').val();
        alert("Send this object to back end for editing\nUpon success make the following call :\nEditQuestionTable.theUsageTable.edit_row(YourQuestionsTable.currentRow, theObj)" + JSON.stringify(theObj, null, ' '));
        YourQuestionsTable.theUsageTable.edit_row(YourQuestionsTable.currentRow, theObj);
        //$.ajax({ url: config.contextPath + "Home/editobject?theObj="_OBJ_ }).done((jRespData) => {
        //    //jData.Name = "Labamba_" + jData.Name.split('_')[1] ;
        //    TheTopTable.theTable.edit_row(this.currentRow, this.currentObject_1);
        //    //this.myModal.toggle();
        //});
    },
    sortCallBack: (e, byWhat, direction) => {
        alert("In Sort Callback \nbyWhat = " + byWhat + "\ndir = " + direction + "\nOffset = " + YourQuestionsTable.theUsageTable.offset + "\nLimit = " + YourQuestionsTable.theUsageTable.itemsPerPage);
        YourQuestionsTable.theUsageTable.start_action();
    },
    getTable: async (offset, limit) => {
        //make an AJAX call and return the ajax response as a promise
        var url = YourQuestionsTable.getPageDataURL;
        url = url.replace('_OFFSET_', offset).replace('_LIMIT_', limit);
        let dt = JSON.parse(await $.ajax({ url: url, context: this }));
        dt.forEach(row => row.question = row.question.ReplaceDanger());
        return JSON.stringify(dt);
    },
    GetRecordCount: () => $.ajax({ url: YourQuestionsTable.TotRecURL, context: this }).then(jData => parseInt(jData)),
    CellRenderCallBack: (row, col, rowData) => {
        switch (col) {
            case "sno": {
                let html_template = '<a target="_blank" href="/VnVOverflow/Home/AnswerToAQuestion?qid=_ID_#answer" class="btn btn-sm btn-warning">_ID_ _ICON_</a>'
                let html = html_template.replace(/_ID_/g, rowData["id"]).replace(/_ICON_/g, '<i class="bi bi-airplane"></i>');
                return html;
            }
            case "Urvashi": return `<img class="img-fluid rounded-3" style="height:40px;" src="https://cdn.icon-icons.com/icons2/1448/PNG/512/42532bullettrain_99078.png" />
                                    <img class="img-fluid rounded-3" style="margin-left:-7px; height:40px;transform:  rotateY(-180deg)" src="https://cdn.icon-icons.com/icons2/1448/PNG/512/42532bullettrain_99078.png" />
            <img class="img-fluid rounded-3" style="height:40px;" src="https://cdn.icon-icons.com/icons2/2079/PNG/512/umbrella_parasol_japan_wagasa_japanese_paper_traditional_beautiful_icon_127305.png" />
                                    <img class="img-fluid rounded-3" style="height:40px;" src="https://cdn.icon-icons.com/icons2/2083/PNG/512/gown_girl_beautiful_wallet_gloves_blond_woman_party_avatar_feminine_icon_127429.png" />`;
            case "insert_time_stamp": return new Date(rowData[col].replace(' ', 'T')).toString().split('GMT')[0] + ' <i class="bi bi-alarm"></i>';
            default: return false;
        }
    },
    AfterLogin: function (user_details) {
        new TemplateRenderer(YourQuestionsTable.data, YourQuestionsTable.tag, "~/Scripts/Components/YourQuestions/YourQuestions.html").start_action().
            then(async jData => {
                if (!YourQuestionsTable.theUsageTable) YourQuestionsTable.theUsageTable = new Pest(YourQuestionsTable, "YourQuestionsTable.theUsageTable");
                YourQuestionsTable.theUsageTable.start_action();
                theApp.AOSInitialize();
                if (YourQuestionsTable.callback)YourQuestionsTable.callback(true);
            })
    },
    start_action: async function (data, tag, callback) {
        YourQuestionsTable.callback = callback;
        YourQuestionsTable.data = data;
        YourQuestionsTable.tag = tag;
        let user_details = await $.ajax({ url: config.contextPath + "Home/GetUserDetails" });
        if (!user_details) {
            LogIn.ShowLoginDialog(YourQuestionsTable.AfterLogin);
            return;
        }
        else YourQuestionsTable.AfterLogin(user_details, BasicAction.user.mail)
    },
    callback: null,
    data: null, tag: null,
    theUsageTable: null,
    TotRecURL: "/VnVOverflow/" + 'Home/GetCountOfQuestionsForEmail',
    getPageDataURL: "/VnVOverflow/" + "Home/GetNextSetOfQuestionsForEmail?offset=_OFFSET_&limit=_LIMIT_&orderby=id&email=sesha.sai",
}
//*****************YourQuestionsTable.start_action(); *********************