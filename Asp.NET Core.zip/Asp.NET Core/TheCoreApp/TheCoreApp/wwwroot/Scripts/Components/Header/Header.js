﻿var Header = {
    myModal: null,
    TheIcon: null,
    start_action: function () {
        (new TemplateRenderer({ obj: "TheHeader" }, "Header", "~/Scripts/Components/Header/Header.html").start_action()).
            then(value => {
                function TakeNavLinkAction(link) {
                    $(".nav-link").removeClass("active");
                    link.addClass("active");
                }
                $(".nav-link").on("click", (e) => TakeNavLinkAction($(e.target)));

                //let url = window.location.pathname; // Returns path only (/path/example.html)
                //let current_link = "a[class*='nav-link'][href='_URL_']".replace(/_URL_/, url);
                //TakeNavLinkAction($(current_link));

                //Header.TheIcon = new Icon();
                //Header.TheIcon.start_action({ "obj_name": "Header.TheIcon" }, "icon_header", "icon_small") 
            });
    },
    SetUserName: function (user_name) {
        Header.TheIcon.SetUserDetails();
    }
}
