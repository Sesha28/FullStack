﻿var ReUseableStuffs =
{
    container_id:"reuse",
    id: "reuse_carousal",
    stuffs: [
        {
            nickname: "Sesha",
            title: "XL Maker",
            author: "Dr.Sesha",
            msg: `Parse XL, Make beautiful XLs with XL maker. XL Maker has been used accross many programs,
                    like<b>CSOMO, Rule Engine, BOQ, NCRTC project </b> etc.`
        },
        {
            nickname: "Ashu",
            title: "SSO {Single Sign On}",
            author: "Ashu Joshi",
            msg: ` A reusable javascript component to perform SSO inside Google.
                    If you were wondering how do I accomplish SSO inside Google,
                    your search ends right here, Ashu's SSO is pure plug and play, a joy to integrate`
        },
        {
            nickname: "Rahul",
            title: "C# Exception gathering",
            author: "Rahul Dubey",
            msg: ` An extension method that stacks all C# exeptions details like <b> Exception Message and StackTrace</b>
                    including those of the inner exceptions into one String. This is widely used accross many programs
                    like <b>RIGHT,COSMO, RmR, ATOM </b> etc. . .`
        },
        {
            nickname: "Hari",
            title: ".NET and Linux",
            author: "B-K Hariprasad",
            msg: `Learn how to use C# .NET Core to build a Linux Service. 
                    This technique was the <b>key ingredient</b> to the success of <b>NMS</b> integration into the <b>DCS baseline </b> `
        }
    ]
}