﻿var TEKBytes_team = {
    sub_title: "My Team",
    title: "Meet the Professionals",
    id: "team",

    mate_1_src: config.contextPath + "img/team-1.jpg",
    about_mate_1: "I am a software developer, learner, teacher and guide working at the grass root level of Mcrosoft. At the end of every day I make sure that I never stop learning and coding . . .",
    mate_1_name: "Dr.SAI Sesha",
    mate_1_role: "Technology Evangelist",

    mate_2_src: config.contextPath + "img/team-4_placeholder.jpg",
    about_mate_2: "I maintain the software and content of this portal, like updates, news items. I aslo help in moderation of answers",
    mate_2_name: "Mr.X",
    mate_2_role: "Site Master",

    mate_3_src: config.contextPath + "img/y.jpg",
    about_mate_3: "I am person with deep knowledge in the ways of <b class='bg-warning text-primary rounded-pill p-1'>V<sub>&</sub>V</b>.This person regulates and decide the right answer to a question",
    mate_3_name: "Madam.Y",
    mate_3_role: "The Owner",

    mate_4_src: config.contextPath + "img/z.jpg",
    about_mate_4: "I am a software developer for <br/><b class='bg-warning text-primary rounded-pill p-1'>V<sub>&</sub>V Overflow</b>. I am a learner in the <b>Full Stack</b> arena",
    mate_4_name: "Madam.Z",
    mate_4_role: "A Full Stack Learner",
}